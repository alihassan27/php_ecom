<?php
include_once('php-graph-sdk-5.x/src/Facebook/autoload.php');
$fb = new Facebook\Facebook(array(
	'app_id' => '512952570279080', // Replace with your app id
	'app_secret' => 'c289bc99f057bc93a84044ef8ec92c7f',  // Replace with your app secret
	'default_graph_version' => 'v3.2',
));

$helper = $fb->getRedirectLoginHelper();
?>