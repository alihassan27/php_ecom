<?php
session_start();
include_once('fb-config.php');
include('../config/connection.php');

try {
  $accessToken = $helper->getAccessToken();
} catch(Facebook\Exceptions\FacebookResponseException $e) {
  // When Graph returns an error
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  // When validation fails or other local issues
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}

if (!isset($accessToken)) {
  if ($helper->getError()) {
    header('HTTP/1.0 401 Unauthorized');
    echo "Error: " . $helper->getError() . "\n";
    echo "Error Code: " . $helper->getErrorCode() . "\n";
    echo "Error Reason: " . $helper->getErrorReason() . "\n";
    echo "Error Description: " . $helper->getErrorDescription() . "\n";
  } else {
    header('HTTP/1.0 400 Bad Request');
    echo 'Bad request';
  }
  exit;
}

if(!$accessToken->isLongLived()){
  // Exchanges a short-lived access token for a long-lived one
  try {
    $accessToken = $oAuth2Client->getLongLivedAccessToken($accessToken);
  } catch (Facebook\Exceptions\FacebookSDKException $e) {
    echo "<p>Error getting long-lived access token: " . $e->getMessage() . "</p>\n\n";
    exit;
  }
}

//$fb->setDefaultAccessToken($accessToken);

# These will fall back to the default access token
$res 	= 	$fb->get('/me',$accessToken->getValue());
$fbUser	=	$res->getDecodedBody();


$resImg		=	$fb->get('/me/picture?type=large&amp;amp;redirect=false',$accessToken->getValue());
$picture	=	$resImg->getGraphObject();

// echo"<pre>";
// print_r($_POST);
// echo"</pre>";
// die();





$_SESSION['auth']		=	true;
$_SESSION['auth_role'] =	"0";
$_SESSION['auth_user'] = [
    'fb_user_id' =>$fbUser['id'],
    'fbUserName' => $fbUser['name'],
];

        // check fb_user_id

        $check_fb_id = "SELECT fb_user_id FROM user WHERE fb_user_id='{$fbUser['id']}'";

        $check_fb_run = mysqli_query($con, $check_fb_id);

        if (mysqli_num_rows($check_fb_run) > 0) {

            header("Location: ../index.php");
            exit(0);
        }
else{
$user_query = "INSERT INTO `user` (`fb_user_id`,`username`) VALUES ('{$fbUser['id']}', '{$fbUser['name']}')";
$user_query_run = mysqli_query($con, $user_query);

// $_SESSION['Id']		=	$fbUser['id'];
// $_SESSION['Name']		=	$fbUser['name'];
$_SESSION['AccessToken']	=	$accessToken->getValue();

header('Location: ../index.php');
exit;
}
?>