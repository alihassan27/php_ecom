# Login-with-Facebook-using-PHP-SDK
Login with Facebook using PHP SDK

View online complete documentation and integration <a href="https://learncodeweb.com/php/login-with-facebook-using-php-sdk/index.php">Click Here</a>

View working example <a href="https://learncodeweb.com/demo/php/login-with-facebook-using-php-sdk/index.php">View Demo</a>

Thank you

Regards Zaid Bin Khalid
