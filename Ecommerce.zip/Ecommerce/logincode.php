<?php

session_start();

include('config/connection.php');

if (isset($_POST['email'])) {

    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);

    $login_query = "SELECT * FROM user WHERE email='$email' AND password='$password' LIMIT 1";
    $login_query_run = mysqli_query($con, $login_query);

    if (mysqli_num_rows($login_query_run) > 0) {
        //(fetching data from db)
        foreach ($login_query_run as $data) {
            $user_id = $data['id'];
            $username = $data['username'];
            $email = $data['email'];
            $role_as = $data['role_as'];
        }

        $_SESSION['auth'] = true;
        $_SESSION['auth_role'] = "$role_as";
        $_SESSION['auth_user'] = [
            'user_id' => $user_id,
            'username' => $username,
            'email' => $email,

        ];
     
//         echo "<pre>";
//         print_r($data);
//         print_r($_SESSION);
//         echo "</pre>";
// die();

        // (1=admin) (0=user)
        if ($_SESSION['auth_role'] == '1') {
            $_SESSION['message'] = "Welcome to dashboard";
            header('Location:Admin/d-index.php');
            exit(0);
        } elseif ($_SESSION['auth_role'] == '0')  {
            $_SESSION['message'] = "You have logged in ";
            header('Location:index.php');
            exit(0);
        }
    } else {
        $_SESSION['message'] = "invalid email or password";
        header('Location:login.php');
        exit(0);
    }
} else {
    $_SESSION['message'] = "You are not allowed to access this file";
    header('Location:login.php');
    exit(0);
}
