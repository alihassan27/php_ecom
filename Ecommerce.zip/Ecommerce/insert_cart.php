<?php
include"config/connection.php";
session_start();

if(isset($_POST['add_to_cart']))
{
    if(isset($_SESSION['auth_user']['user_id'])){
$product_id = mysqli_real_escape_string($con, $_POST['id']);
$user_id = mysqli_real_escape_string($con, $_SESSION['auth_user']['user_id']);
$name = mysqli_real_escape_string($con, $_POST['name']);
$description = mysqli_real_escape_string($con, $_POST['description']);
$taste = mysqli_real_escape_string($con, $_POST['taste']);
$size = mysqli_real_escape_string($con, $_POST['size']);
$quantity = mysqli_real_escape_string($con, $_POST['quantity']);
$price = mysqli_real_escape_string($con, $_POST['price']);
$image = mysqli_real_escape_string($con, $_POST['image']);
$total = mysqli_real_escape_string($con, $_POST['total']);
$query = mysqli_query($con,"INSERT INTO `cart` (`product_id`,`user_id`, `name`,`description`,`taste`,`size`,`quantity`, `price`, `image`,`total`)
    VALUES('$product_id','$user_id','$name','$description','$taste','$size','$quantity','$price','$image','$total')");
    header('Location: view_cart.php');
    exit(0);
}elseif(isset($_SESSION['auth_user']['fb_user_id'])){
    $product_id = mysqli_real_escape_string($con, $_POST['id']);   
    $fb_user_id = mysqli_real_escape_string($con, $_SESSION['auth_user']['fb_user_id']);
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $description = mysqli_real_escape_string($con, $_POST['description']);
    $taste = mysqli_real_escape_string($con, $_POST['taste']);
    $size = mysqli_real_escape_string($con, $_POST['size']);
    $quantity = mysqli_real_escape_string($con, $_POST['quantity']);
    $price = mysqli_real_escape_string($con, $_POST['price']);
    $image = mysqli_real_escape_string($con, $_POST['image']);
    $total = mysqli_real_escape_string($con, $_POST['total']);
    $query = mysqli_query($con,"INSERT INTO `cart` (`product_id`,`fb_user_id`, `name`,`description`,`taste`,`size`,`quantity`, `price`, `image`,`total`)
        VALUES('$product_id','{$_SESSION['auth_user']['fb_user_id']}','$name','$description','$taste','$size','$quantity','$price','$image','$total')");
        header('Location: view_cart.php');
        exit(0);  
}elseif(isset($_SESSION['google_id'])){
    $product_id = mysqli_real_escape_string($con, $_POST['id']);   
    $google_user_id = mysqli_real_escape_string($con, $_SESSION['google_id']);
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $description = mysqli_real_escape_string($con, $_POST['description']);
    $taste = mysqli_real_escape_string($con, $_POST['taste']);
    $size = mysqli_real_escape_string($con, $_POST['size']);
    $quantity = mysqli_real_escape_string($con, $_POST['quantity']);
    $price = mysqli_real_escape_string($con, $_POST['price']);
    $image = mysqli_real_escape_string($con, $_POST['image']);
    $total = mysqli_real_escape_string($con, $_POST['total']);
    $query = mysqli_query($con,"INSERT INTO `cart` (`product_id`,`google_user_id`, `name`,`description`,`taste`,`size`,`quantity`, `price`, `image`,`total`)
        VALUES('$product_id','{$_SESSION['google_id']}','$name','$description','$taste','$size','$quantity','$price','$image','$total')");
        header('Location: view_cart.php');
        exit(0);  
}
else{
    echo"Login First";
}
}
?>