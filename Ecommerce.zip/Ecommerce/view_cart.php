<?php
session_start();
include("config/connection.php");
require_once('paypal/dbclass.php');
include("includes/header.php");
include("includes/scripts.php");

include("stripe-payment-method/config.php");

?>

<head>
    <style>
        .stripe-button-el{
            position: absolute;
            right: 96px;
        }
    </style>
</head>

<body class="sub_page">

    <div class="hero_area">
        <div class="bg-box">
            <img src="assets/images/hero-bg.jpg" alt="">
        </div>
        <!-- header section strats -->
        <header class="header_section">
            <div class="container">
                <nav class="navbar navbar-expand-lg custom_nav-container ">
                    <a class="navbar-brand" href="index.php">
                        <span>
                            Feane
                        </span>
                    </a>

                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class=""> </span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav  mx-auto ">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php">Home </a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="product_show.php">Products</a>
                            </li>
                           // <?php
                           // $navbarCategory = "SELECT * FROM categories WHERE navbar_status='0' AND status='0' ";
                           // $navbar_run = mysqli_query($con, $navbarCategory);
                           // 
                           // if(mysqli_num_rows($navbar_run) > 0)
                           // {
                           //     foreach($navbar_run as $navItem)
                           //     {
                           //         ?>
                            <!-- <li class="nav-item">
                                <a class="nav-link" href="product_show.php?cat=<?= $navItem['slug']; ?>"><?= $navItem['name']; ?></a>
                            </li> -->
                           // <?php
                           //     }
                           // }
                           // 
                           // ?>

<li class="btn-group">
                                <button type="button" style="border-radius: 60px;" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">


                                    <?php

                                      if (isset($_SESSION['auth_user']['username'])) {
                                    
                                      ?>

                                      <?= $_SESSION['auth_user']['username']; ?>
                                      <?php
                                      }elseif(isset($_SESSION['auth_user']['fbUserName'])){
                                        ?>
                                        <?= $_SESSION['auth_user']['fbUserName']; ?>
                                    <?php
                                        }elseif(isset($_SESSION['user_first_name'])){
                                      ?>
                                        <?= $_SESSION['user_first_name']; ?>  
                                    <?php
                                    }
                                        else {
                                        echo "Login First";
                                      }
                                  
                                    ?>

                                </button>
                                    <?php
                                    if (isset($_SESSION['auth_user']['username'])) {
                                      ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="user_profile.php">My Profile</a>
                                    
                                      <form action="logout.php" method="POST" style="font-size: 20px;">
                                        <button type="submit" name="btn_logout" style="width: 10rem; border:none; background-color:transparent; color:white">Logout</button>
                                      </form>
                                    </div>              
                                    <?php
                                    }elseif(isset($_SESSION['auth_user']['fbUserName'])){             
                                    ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="user_profile.php">My Profile</a>

                                      <form action="logout.php" method="POST" style="font-size: 20px;">
                                        <button type="submit" name="btn_logout" style="width: 10rem; border:none; background-color:transparent; color:white">Logout</button>
                                      </form>
                                    </div>
                                    <?php
                                        }elseif(isset($_SESSION['user_first_name'])){             
                                        ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="user_profile.php">My Profile</a>

                                      <form action="logout.php" method="POST" style="font-size: 20px;">
                                        <button type="submit" name="btn_logout" style="width: 10rem; border:none; background-color:transparent; color:white">Logout</button>
                                      </form>
                                    </div>                                                                           
                                    <?php 
                                     }
                                     else{
                                    ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="login.php">Login</a>
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="Registration.php">Register Yourself</a>
                                    </div>              
                                    <?php
                                    }
                                    ?>
                            </li>
                            
                        </ul>
                        <div class="user_option">
                            <a href="registration.php" class="user_link">
                                <i class="fa fa-user" aria-hidden="true"></i>
                            </a>

                            <?php
                                if (isset($_SESSION['auth_user']['user_id'])) {
                                    $cart_count = mysqli_query($con, "SELECT * FROM `cart` WHERE user_id='{$_SESSION['auth_user']['user_id']}'");
                                    $cart_rows = mysqli_num_rows($cart_count);
                                } elseif (isset($_SESSION['auth_user']['fb_user_id'])) {
                                    $cart_count = mysqli_query($con, "SELECT * FROM `cart` WHERE fb_user_id='{$_SESSION['auth_user']['fb_user_id']}'");
                                    $cart_rows = mysqli_num_rows($cart_count);
                                } elseif (isset($_SESSION['google_id'])) {
                                    $cart_count = mysqli_query($con, "SELECT * FROM `cart` WHERE google_user_id='{$_SESSION['google_id']}'");
                                    $cart_rows = mysqli_num_rows($cart_count);
                                } else {
                                    $cart_rows = '';
                                }
                                ?>
                                <?php
                                if (isset($_SESSION['auth_user']['user_id'])) {

                                ?>
                                    <a href="view_cart.php" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span class="bg-danger" style="padding: 5px; border-radius: 50%;font-size: 9px; position: absolute; top: 10px;"><?php echo $cart_rows  ?></span></i>
                                    </a>

                                <?php
                                } elseif (isset($_SESSION['auth_user']['fb_user_id'])) {
                                ?>
                                    <a href="view_cart.php" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span class="bg-danger" style="padding: 5px; border-radius: 50%;font-size: 9px; position: absolute; top: 10px;"><?php echo $cart_rows  ?></span></i>
                                    </a>
                                <?php
                                } elseif ( isset($_SESSION['google_id'])) {
                                ?>
                                    <a href="view_cart.php" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span class="bg-danger" style="padding: 5px; border-radius: 50%;font-size: 9px; position: absolute; top: 10px;"><?php echo $cart_rows  ?></span></i>
                                    </a>

                                <?php
                                } else {
                                ?>
                                    <a href="*" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span></span></i>
                                    </a>
                                <?php
                                }
                                ?>
                        </div>
                    </div>
                </nav>
            </div>
        </header>
        <!-- end header section -->
    </div>

    <!-- food section -->


    

    <section class="food_section layout_padding">
        <div class="container">
        <?php
    if (isset($_SESSION['auth_user']['user_id'])) {
    ?>

        <?php
        $query_p = mysqli_query($con, "SELECT * FROM `cart` Where `user_id`='{$_SESSION['auth_user']['user_id']}'");
        if (mysqli_num_rows($query_p) > 0) {
        ?>
            <div class="heading_container heading_center">
                <h2>
                    Your Cart
                </h2>
            </div>


            <div class="col-md-12" id="cart_table">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Image</th>
                                <th>Description</th>
                                <th>Taste</th>
                                <th>Size</th>
                                <th>Real Price</th>
                                <th>Quantity</th>
                                <th>New Total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $user_id = $_SESSION['auth_user']['user_id'];
                            $query = mysqli_query($con, "SELECT * FROM cart where `user_id`='{$_SESSION['auth_user']['user_id']}' ");
                            $total = 0;
                            
                            while ($row = mysqli_fetch_array($query)) {
                                ?>
                            
                            <tr>
                                <td><?= $row['name'] ?></td>
                                <td><img src="Admin/images/product/<?= $row['image']; ?>" alt="" height="80" width="80" ;></td>
                                <td><?= $row['description'] ?></td>
                                <td><?= $row['taste'] ?></td>
                                <td><?= $row['size'] ?></td>
                                <td class="real-price"><?php echo $row['price'] .' $'; ?></td>                                
                            <td>
                            <form id="frm<?php echo $row['id']; ?>">
                                            <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                                            <input type="hidden" class="price" name="price" value="<?php echo $row['price'] ?>">
                                            <input type="number" name="quantity" value="<?php echo $row['quantity'] ?>" onchange="up_qty(<?php echo $row['id']; ?>)" onkeyup="up_qty(<?php echo $row['id']; ?>)">
                                        </form>
                            </td>

                                        <td>
                                        <?php echo $row['total']; ?>
                                    </td>
                                <td><a href="del_cart.php?id= <?= $row['id']; ?>"  onclick="return confirm('Are You Sure, You want to Delete?')" name="btn_del" class="btn btn-danger"><i class="fa fa-trash"></a></td></i>
                            </tr>
                            
                      
                            <?php
                                $total = $total + ($row["quantity"] * $row["price"]);
                            }                        
                            ?>
                            <tr>
                                <td class="total-text" align="right" colspan="7">Total amount ($)</td>
                                <td><?php echo number_format($total, 2); ?></td>
                            </tr>     </tbody>
                    </table>

                    </div>


        </div>

        <!-- paypal working -->
        <?php
            $user_id = $_SESSION['auth_user']['user_id'];
            $p_query = mysqli_query($con, "SELECT * FROM cart where `user_id`='$user_id'");
            while ($p_row = mysqli_fetch_array($p_query)) {
                ?>        
        <div>
        <form method='post' action='<?php echo PAYPAL_URL; ?>'>
            <!-- PayPal business email to collect payments -->
            <input type='hidden' name='business' value='<?php echo PAYPAL_EMAIL; ?>'>
            <!-- Details of item that customers will purchase -->
            <input type='hidden' name='item_number' value='<?php echo $p_row['id']; ?>'>
            <input type='hidden' name='item_name' value='<?php echo $p_row['name']; ?>'>
            <input type='hidden' name='item_description' value='<?php echo $p_row['description']; ?>'>
            <input type='hidden' name='item_quantity' value='<?php echo $p_row['quantity']; ?>'>
            <input type='hidden' name='amount' value='<?php echo $total; ?>'>
            <?php
            }
            ?>
            <input type='hidden' name='cc' value='<?php echo CURRENCY; ?>'>
            <input type='hidden' name='st' value='1'>            

            <input type='hidden' name='return' value='<?php echo RETURN_URL; ?>'>
            
            <!-- PayPal return, cancel & IPN URLs -->
            <input type='hidden' name='cancel_return' value='<?php echo CANCEL_URL; ?>'>

            <input type="hidden" name="cmd" value="_xclick">

            <!-- Specify a Pay Now button. -->
                <div class="col-md-2 ml-auto">
        <button type='submit' class='pay btn btn-success'>Paypal Pay</button>
        </div>  
        </form>      
        </div>


        <!-- Stripe Integration -->
        <form action="stripe-payment-method/submit.php" method="post">
        <?php
            $user_id = $_SESSION['auth_user']['user_id'];
            $p_query = mysqli_query($con, "SELECT * FROM cart where `user_id`='{$_SESSION['auth_user']['user_id']}'");
            while ($p_row = mysqli_fetch_array($p_query)) {
            ?>
            <input type='hidden' name='item_number' value='<?php echo $p_row['product_id']; ?>'>            
            <input type='hidden' name='item_name' value='<?php echo $p_row['name']; ?>'>
            <input type='hidden' name='item_description' value='<?php echo $p_row['description']; ?>'>
            <input type='hidden' name='item_quantity' value='<?php echo $p_row['quantity']; ?>'>
            <input type='hidden' name='amount' value='<?php echo $total; ?>'>
            <script src="https://checkout.stripe.com/checkout.js" class="stripe-button" 
            data-key="<?php echo $publishableKey ?>" 
            data-amount="<?php echo $total * 100; ?>" data-currency="USD">
            </script>
        <?php
        }
        ?>

        </form>

<?php

}else{

    echo"<h1>Your Cart is Empty</h1>";
}
?>

                                            <!-- For facebook user view_cart -->

<?php
} elseif (isset($_SESSION['auth_user']['fb_user_id'])) {    
?>
        <?php
        $query_p = mysqli_query($con, "SELECT * FROM `cart` Where `fb_user_id`='{$_SESSION['auth_user']['fb_user_id']}'");
        if (mysqli_num_rows($query_p) > 0) {
        ?>
            <div class="heading_container heading_center">
                <h2>
                    Your Cart
                </h2>
            </div>


            <div class="col-md-12" id="cart_table">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Image</th>
                                <th>Description</th>
                                <th>Taste</th>
                                <th>Size</th>
                                <th>Real Price</th>
                                <th>Quantity</th>
                                <th>New Total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $user_id = $_SESSION['auth_user']['fb_user_id'];
                            $query = mysqli_query($con, "SELECT * FROM cart where `fb_user_id`='{$_SESSION['auth_user']['fb_user_id']}' ");
                            $total = 0;
                            
                            while ($row = mysqli_fetch_array($query)) {
                                ?>
                            
                            <tr>
                                <td><?= $row['name'] ?></td>
                                <td><img src="Admin/images/product/<?= $row['image']; ?>" alt="" height="80" width="80" ;></td>
                                <td><?= $row['description'] ?></td>
                                <td><?= $row['taste'] ?></td>
                                <td><?= $row['size'] ?></td>
                                <td class="real-price"><?php echo $row['price'] .' $'; ?></td>                                
                            <td>
                            <form id="frm<?php echo $row['id']; ?>">
                                            <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                                            <input type="hidden" class="price" name="price" value="<?php echo $row['price'] ?>">
                                            <input type="number" name="quantity" value="<?php echo $row['quantity'] ?>" onchange="up_qty(<?php echo $row['id']; ?>)" onkeyup="up_qty(<?php echo $row['id']; ?>)">
                                        </form>
                            </td>

                                        <td>
                                        <?php echo $row['total']; ?>
                                    </td>
                                <td><a href="del_cart.php?id= <?= $row['id']; ?>"  onclick="return confirm('Are You Sure, You want to Delete?')" name="btn_del" class="btn btn-danger"><i class="fa fa-trash"></a></td></i>
                            </tr>
                            
                      
                            <?php
                                $total = $total + ($row["quantity"] * $row["price"]);
                            }                        
                            ?>
                            <tr>
                                <td class="total-text" align="right" colspan="7">Total amount ($)</td>
                                <td><?php echo number_format($total, 2); ?></td>
                            </tr>     </tbody>
                    </table>

                    </div>


        </div>

        <!-- paypal working -->
        <?php
            $user_id = $_SESSION['auth_user']['fb_user_id'];
            $p_query = mysqli_query($con, "SELECT * FROM cart where `fb_user_id`='{$_SESSION['auth_user']['fb_user_id']}'");
            while ($p_row = mysqli_fetch_array($p_query)) {
                ?>        
        <div>
        <form method='post' action='<?php echo PAYPAL_URL; ?>'>
            <!-- PayPal business email to collect payments -->
            <input type='hidden' name='business' value='<?php echo PAYPAL_EMAIL; ?>'>
            <!-- Details of item that customers will purchase -->
            <input type='hidden' name='item_number' value='<?php echo $p_row['id']; ?>'>
            <input type='hidden' name='item_name' value='<?php echo $p_row['name']; ?>'>
            <input type='hidden' name='item_description' value='<?php echo $p_row['description']; ?>'>
            <input type='hidden' name='item_quantity' value='<?php echo $p_row['quantity']; ?>'>
            <input type='hidden' name='amount' value='<?php echo $total; ?>'>
            <?php
            }
            ?>
            <input type='hidden' name='cc' value='<?php echo CURRENCY; ?>'>
            <input type='hidden' name='st' value='1'>            

            <input type='hidden' name='return' value='<?php echo RETURN_URL; ?>'>
            
            <!-- PayPal return, cancel & IPN URLs -->
            <input type='hidden' name='cancel_return' value='<?php echo CANCEL_URL; ?>'>

            <input type="hidden" name="cmd" value="_xclick">

            <!-- Specify a Pay Now button. -->
                <div class="col-md-2 ml-auto">
        <button type='submit' class='pay btn btn-success'>Paypal Pay</button>
        </div>  
        </form>      
        </div>

        <!-- Stripe Integration -->
        <form action="stripe-payment-method/submit.php" method="post">
        <?php
            $user_id = $_SESSION['auth_user']['fb_user_id'];
            $p_query = mysqli_query($con, "SELECT * FROM cart where `fb_user_id`='$user_id'");
            while ($p_row = mysqli_fetch_array($p_query)) {
            ?>
            <input type='hidden' name='item_number' value='<?php echo $p_row['product_id']; ?>'>            
            <input type='hidden' name='item_name' value='<?php echo $p_row['name']; ?>'>
            <input type='hidden' name='item_description' value='<?php echo $p_row['description']; ?>'>
            <input type='hidden' name='item_quantity' value='<?php echo $p_row['quantity']; ?>'>
            <input type='hidden' name='amount' value='<?php echo $total; ?>'>
            <script src="https://checkout.stripe.com/checkout.js" class="stripe-button" 
            data-key="<?php echo $publishableKey ?>" 
            data-amount="<?php echo $total * 100; ?>" data-currency="USD">
            </script>
        <?php
        }
        ?>

        </form>        

<?php

}else{

    echo"<h1>Your Cart is Empty</h1>";
}
?>

                                    <!-- For Google user view cart -->
<?php
} elseif (isset($_SESSION['google_id'])) {
?>

<?php
        $query_p = mysqli_query($con, "SELECT * FROM `cart` Where `google_user_id`='{$_SESSION['google_id']}'");
        if (mysqli_num_rows($query_p) > 0) {
        ?>
            <div class="heading_container heading_center">
                <h2>
                    Your Cart
                </h2>
            </div>


            <div class="col-md-12" id="cart_table">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Image</th>
                                <th>Description</th>
                                <th>Taste</th>
                                <th>Size</th>
                                <th>Real Price</th>
                                <th>Quantity</th>
                                <th>New Total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $user_id = $_SESSION['google_id'];
                            $query = mysqli_query($con, "SELECT * FROM cart where `google_user_id`='{$_SESSION['google_id']}' ");
                            $total = 0;
                            
                            while ($row = mysqli_fetch_array($query)) {
                                ?>
                            
                            <tr>
                                <td><?= $row['name'] ?></td>
                                <td><img src="Admin/images/product/<?= $row['image']; ?>" alt="" height="80" width="80" ;></td>
                                <td><?= $row['description'] ?></td>
                                <td><?= $row['taste'] ?></td>
                                <td><?= $row['size'] ?></td>
                                <td class="real-price"><?php echo $row['price'] .' $'; ?></td>                                
                            <td>
                            <form id="frm<?php echo $row['id']; ?>">
                                            <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                                            <input type="hidden" class="price" name="price" value="<?php echo $row['price'] ?>">
                                            <input type="number" name="quantity" value="<?php echo $row['quantity'] ?>" onchange="up_qty(<?php echo $row['id']; ?>)" onkeyup="up_qty(<?php echo $row['id']; ?>)">
                                        </form>
                            </td>

                                        <td>
                                        <?php echo $row['total']; ?>
                                    </td>
                                <td><a href="del_cart.php?id= <?= $row['id']; ?>"  onclick="return confirm('Are You Sure, You want to Delete?')" name="btn_del" class="btn btn-danger"><i class="fa fa-trash"></a></td></i>
                            </tr>
                            
                      
                            <?php
                                $total = $total + ($row["quantity"] * $row["price"]);
                            }                        
                            ?>
                            <tr>
                                <td class="total-text" align="right" colspan="7">Total amount ($)</td>
                                <td><?php echo number_format($total, 2); ?></td>
                            </tr>     </tbody>
                    </table>

                    </div>


        </div>

        <!-- paypal working -->
        <?php
            $user_id = $_SESSION['google_id'];
            $p_query = mysqli_query($con, "SELECT * FROM cart where `google_user_id`='{$_SESSION['google_id']}'");
            while ($p_row = mysqli_fetch_array($p_query)) {
                ?>        
        <div>
        <form method='post' action='<?php echo PAYPAL_URL; ?>'>
            <!-- PayPal business email to collect payments -->
            <input type='hidden' name='business' value='<?php echo PAYPAL_EMAIL; ?>'>
            <!-- Details of item that customers will purchase -->
            <input type='hidden' name='item_number' value='<?php echo $p_row['id']; ?>'>
            <input type='hidden' name='item_name' value='<?php echo $p_row['name']; ?>'>
            <input type='hidden' name='item_description' value='<?php echo $p_row['description']; ?>'>
            <input type='hidden' name='item_quantity' value='<?php echo $p_row['quantity']; ?>'>
            <input type='hidden' name='amount' value='<?php echo $total; ?>'>
            <?php
            }
            ?>
            <input type='hidden' name='cc' value='<?php echo CURRENCY; ?>'>
            <input type='hidden' name='st' value='1'>            

            <input type='hidden' name='return' value='<?php echo RETURN_URL; ?>'>
            
            <!-- PayPal return, cancel & IPN URLs -->
            <input type='hidden' name='cancel_return' value='<?php echo CANCEL_URL; ?>'>

            <input type="hidden" name="cmd" value="_xclick">

            <!-- Specify a Pay Now button. -->
                <div class="col-md-2 ml-auto">
        <button type='submit' class='pay btn btn-success'>Paypal Pay</button>
        </div>  
        </form>      
        </div>

        <!-- Stripe Integration -->
        <form action="stripe-payment-method/submit.php" method="post">
        <?php
            $user_id = $_SESSION['google_id'];
            $p_query = mysqli_query($con, "SELECT * FROM cart where `google_user_id`='$user_id'");
            while ($p_row = mysqli_fetch_array($p_query)) {
            ?>
            <input type='hidden' name='item_number' value='<?php echo $p_row['product_id']; ?>'>            
            <input type='hidden' name='item_name' value='<?php echo $p_row['name']; ?>'>
            <input type='hidden' name='item_description' value='<?php echo $p_row['description']; ?>'>
            <input type='hidden' name='item_quantity' value='<?php echo $p_row['quantity']; ?>'>
            <input type='hidden' name='amount' value='<?php echo $total; ?>'>
            <script src="https://checkout.stripe.com/checkout.js" class="stripe-button" 
            data-key="<?php echo $publishableKey ?>" 
            data-amount="<?php echo $total * 100; ?>" data-currency="USD">
            </script>
        <?php
        }
        ?>

        </form>
        
<?php

}else{

    echo"<h1>Your Cart is Empty</h1>";
}
?>
<?php
}?>

        <div class="btn-box">
            <a href="">
                View More
            </a>
        </div>
        

        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        

        
    <script>
        function up_qty(id) {
            let productData = $("#frm" + id).serializeArray();
            let pid = id;
            let price = productData[1]['value'];
            let qty = productData[2]['value'];
            let totalPrice = price * qty;
            // console.log(totalPrice);
            // return;
            $.ajax({
                url: 'update_cart.php',
                type: 'POST',
                data: {
                    'id': pid,
                    'quantity': qty,
                    'price': price,
                    'total': totalPrice,

                },

                success: function(res) {
                    $("#cart_table").html(res);

                }
            });
        }
    </script>

    </section>

<?php
    include_once('includes/footer.php');
?>