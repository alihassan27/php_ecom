<?php
session_start();
include("config/connection.php");
include("includes/header.php");
?>

<body class="sub_page">

    <div class="hero_area">
        <div class="bg-box">
            <img src="assets/images/hero-bg.jpg" alt="">
        </div>
        <!-- header section strats -->
        <header class="header_section">
            <div class="container">
                <nav class="navbar navbar-expand-lg custom_nav-container ">
                    <a class="navbar-brand" href="index.php">
                        <span>
                            Feane
                        </span>
                    </a>

                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class=""> </span>
                    </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav  mx-auto ">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php">Home </a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="product_show.php">Products</a>
                            </li>

                            <li class="btn-group">
                                <button type="button" style="border-radius: 60px;" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">


                                    <?php

                                      if (isset($_SESSION['auth_user']['username'])) {
                                    
                                      ?>

                                      <?= $_SESSION['auth_user']['username']; ?>
                                      <?php
                                      }elseif(isset($_SESSION['auth_user']['fbUserName'])){
                                        ?>
                                        <?= $_SESSION['auth_user']['fbUserName']; ?>
                                    <?php
                                        }elseif(isset($_SESSION['user_first_name'])){
                                      ?>
                                        <?= $_SESSION['user_first_name']; ?>  
                                    <?php
                                    }
                                        else {
                                        echo "Login First";
                                      }
                                  
                                    ?>

                                </button>
                                    <?php
                                    if (isset($_SESSION['auth_user']['username'])) {
                                      ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="#">My Profile</a>
                                    
                                      <form action="logout.php" method="POST" style="font-size: 20px;">
                                        <button type="submit" name="btn_logout" style="width: 10rem; border:none; background-color:transparent; color:white">Logout</button>
                                      </form>
                                    </div>              
                                    <?php
                                    }elseif(isset($_SESSION['auth_user']['fbUserName'])){             
                                    ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="#">My Profile</a>

                                      <form action="logout.php" method="POST" style="font-size: 20px;">
                                        <button type="submit" name="btn_logout" style="width: 10rem; border:none; background-color:transparent; color:white">Logout</button>
                                      </form>
                                    </div>
                                    <?php
                                        }elseif(isset($_SESSION['user_first_name'])){             
                                        ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="#">My Profile</a>

                                      <form action="logout.php" method="POST" style="font-size: 20px;">
                                        <button type="submit" name="btn_logout" style="width: 10rem; border:none; background-color:transparent; color:white">Logout</button>
                                      </form>
                                    </div>                                                                           
                                    <?php 
                                     }
                                     else{
                                    ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="login.php">Login</a>
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="Registration.php">Register Yourself</a>
                                    </div>              
                                    <?php
                                    }
                                    ?>
                            </li>
                        </ul>
                        <div class="user_option">
                            <a href="registration.php" class="user_link">
                                <i class="fa fa-user" aria-hidden="true"></i>
                            </a>
                            <?php
                                if (isset($_SESSION['auth_user']['user_id'])) {
                                    $cart_count = mysqli_query($con, "SELECT * FROM `cart` WHERE user_id='{$_SESSION['auth_user']['user_id']}'");
                                    $cart_rows = mysqli_num_rows($cart_count);
                                } elseif (isset($_SESSION['auth_user']['fb_user_id'])) {
                                    $cart_count = mysqli_query($con, "SELECT * FROM `cart` WHERE fb_user_id='{$_SESSION['auth_user']['fb_user_id']}'");
                                    $cart_rows = mysqli_num_rows($cart_count);
                                } elseif (isset($_SESSION['google_id'])) {
                                    $cart_count = mysqli_query($con, "SELECT * FROM `cart` WHERE google_user_id='{$_SESSION['google_id']}'");
                                    $cart_rows = mysqli_num_rows($cart_count);
                                } else {
                                    $cart_rows = '';
                                }
                                ?>
                                <?php
                                if (isset($_SESSION['auth_user']['user_id'])) {

                                ?>
                                    <a href="view_cart.php" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span class="bg-danger" style="padding: 5px; border-radius: 50%;font-size: 9px; position: absolute; top: 10px;"><?php echo $cart_rows  ?></span></i>
                                    </a>

                                <?php
                                } elseif (isset($_SESSION['auth_user']['fb_user_id'])) {
                                ?>
                                    <a href="view_cart.php" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span class="bg-danger" style="padding: 5px; border-radius: 50%;font-size: 9px; position: absolute; top: 10px;"><?php echo $cart_rows  ?></span></i>
                                    </a>
                                <?php
                                } elseif ( isset($_SESSION['google_id'])) {
                                ?>
                                    <a href="view_cart.php" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span class="bg-danger" style="padding: 5px; border-radius: 50%;font-size: 9px; position: absolute; top: 10px;"><?php echo $cart_rows  ?></span></i>
                                    </a>

                                <?php
                                } else {
                                ?>
                                    <a href="*" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span></span></i>
                                    </a>
                                <?php
                                }
                                ?>

                        </div>
                    </div>
                </nav>
            </div>
        </header>
        <!-- end header section -->
    </div>

    <section>
        <div class="row">
            <?php
            $user_id = $_SESSION['google_id'] ?? $_SESSION['auth_user']['fb_user_id'] ?? $_SESSION['auth_user']['user_id'] ?? '';
            if(isset($_SESSION['google_id'])){
            $s_query = mysqli_query($con, "SELECT * FROM user where google_user_id='{$_SESSION['google_id']}'");
            while($s_row = mysqli_fetch_array($s_query)){
            ?>
        <div class="col-md-6 my-5 bg-dark text-white p-5 mx-auto">
            <table class="table table-bordered">
                <thead class="text-bold"><b>User Details:</b></thead>
                <tbody>
                    <tr class="text-white">
                    <th>Name:</th>
                    <th>Email:</th>
                    </tr>
                    <tr  class="text-white">
                        <td><?= $s_row['username']; ?></td>
                        <td> <?= $s_row['email']; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <?php
        
    }
}elseif(isset($_SESSION['auth_user']['fb_user_id'])){
    $s_query = mysqli_query($con, "SELECT * FROM user where fb_user_id='{$_SESSION['auth_user']['fb_user_id']}'");
    while($s_row = mysqli_fetch_array($s_query)){ 
?>
        <div class="col-md-6 my-5 bg-dark text-white p-5 mx-auto">
            <table class="table table-bordered">
                <thead class="text-bold"><b>User Details:</b></thead>
                <tbody>
                    <tr class="text-white">
                    <th>Name:</th>
                    <th>Email:</th>
                    </tr>
                    <tr  class="text-white">
                        <td><?= $s_row['username']; ?></td>
                        <td> <?= $s_row['email']; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <?php
    }   
    }elseif(isset($_SESSION['auth_user']['user_id'])){
        $s_query = mysqli_query($con, "SELECT * FROM user where `id`='{$_SESSION['auth_user']['user_id']}'");
        while($s_row = mysqli_fetch_array($s_query)){
    ?>
        <div class="col-md-6 my-5 bg-dark text-white p-5 mx-auto">
            <table class="table table-bordered">
                <thead class="text-bold"><b>User Details:</b></thead>
                <tbody>
                    <tr class="text-white">
                    <th>Name:</th>
                    <th>Email:</th>
                    </tr>
                    <tr  class="text-white">
                        <td><?= $s_row['username']; ?></td>
                        <td> <?= $s_row['email']; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <?php
        }
    }
        ?>
    </section>


    <?php
    include("includes/footer.php");
    include("includes/scripts.php");
?>
</body>
</html>
    
