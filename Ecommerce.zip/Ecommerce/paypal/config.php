<?php

// Database Configuration 
define('DB_HOST', 'localhost'); 
define('DB_NAME', 'ecom'); 
define('DB_USERNAME', 'root'); 
define('DB_PASSWORD', ''); 

// PayPal Configuration
define('PAYPAL_EMAIL', 'sb-qk4hc21273540@seller.example.com'); 
define('RETURN_URL', 'http://localhost/Ecommerce/paypal/notify.php'); 
define('CANCEL_URL', 'http://localhost/Ecommerce/paypal/cancel.php'); 
 
define('CURRENCY', 'USD'); 
define('PAYPAL_SANDBOX', TRUE); // TRUE or FALSE 
define('LOCAL_CERTIFICATE', FALSE); // TRUE or FALSE

if (PAYPAL_SANDBOX === TRUE){
	$paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
}else{
	$paypal_url = "https://www.paypal.com/cgi-bin/webscr";
}
// PayPal IPN Data Validate URL
define('PAYPAL_URL', $paypal_url);