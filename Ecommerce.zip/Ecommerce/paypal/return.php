<?php
echo'<pre>';
print_r($_REQUEST);
echo'</pre>';
die();
?>
<html>
<head>
<title>Payment Confirmed</title>
</head>
<body>
    <div style="width:700px; margin:50 auto;">
        <h1>Your paymeny has been received successfully.<br /> Thank you!</h1>
    </div>

<br /><br />

</body>
</html>