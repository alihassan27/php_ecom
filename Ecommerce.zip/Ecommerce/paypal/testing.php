<?php
// database table name is :table
require 'PHPMailer/PHPMailerAutoload.php';
function Selectdata($table, $condition)
{
    global $conn, $result, $selectarray, $rowcount;
    $sql = "SELECT * from " . $table . " " . $condition . " ";
    $result = $conn->query($sql);
    $rowcount = $result->num_rows;
    $selectarray = array();
    while ($row = $result->fetch_assoc()) {
        $selectarray[] = $row;
    }
    return $result;
}

// function for join
function outerjoin($query)
{
    global $conn, $result, $selectoutter, $rowcount;
    $sql = "" . $query . "";
    $result = $conn->query($sql);
    $rowcount = $result->num_rows;
    $selectoutter = array();
    while ($row = $result->fetch_assoc()) {
        $selectoutter[] = $row;
    }
}

$mail = new PHPMailer;
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'kumaresh.arun93@gmail.com';
$mail->Password = 'xxxxxxxxxxxxx';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;
$mail->SMTPDebug = 1;
$mail->setFrom('kumaresh.arun93@gmail.com', 'Arun');
$mail->addAddress('kumaresh.boss@gmail.com', 'kumaresh');

$mail->IsHTML(true);
$mail->Subject = 'Messages From Forum';
$table = "mdl_course";
$condition = "";
$selectcourse = Selectdata($condition, $table);

$body = '';
foreach ($selectarray as $cid) {
    $query = "SELECT a.name as forumname,b.name as discussion,c.message,c.userid,d.firstname,d.email,d.phone1 
    from mdl_forum as a inner join mdl_forum_discussions b on a.id=b.forum 
    inner join mdl_forum_posts c on b.id=c.discussion inner join mdl_user d on c.userid=d.id where a.course=" . $cid['id'] . 
    " and a.category=1 and from_unixtime(c.modified,'%Y-%m-%d')=CURDATE()";
    $selectmsg = outerjoin($query);
    foreach ($selectoutter as $fmsg) {
        $body .=  '<p><b>Forum Name:</b>&nbsp;&nbsp;&nbsp;' . $fmsg['forumname'] . '</p>';
        $body .= '<p><b>Discussion Name:</b>&nbsp;&nbsp;&nbsp;' . $fmsg['discussion'] . '</p>';
        $body .= '<p><b>Message:</b>&nbsp;&nbsp;&nbsp;' . $fmsg['message'] . '</p>';
    }
}

$mail->Body = $body;
if (!$send) {
    echo 'Message could not be sent.';
    // echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';
}