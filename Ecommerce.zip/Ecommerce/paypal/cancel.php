<?php

?>
<h1>Sorry! Your PayPal Payment has been cancelled.</h1>

<br /><br />
