<?php
session_start();

if(isset($_POST['btn_logout']))
{
    unset($_SESSION['auth']);
    unset($_SESSION['auth_role']);
    unset($_SESSION['auth_user']);

unset($_SESSION['fbUserId']);
unset($_SESSION['fbUserName']);
unset($_SESSION['fbAccessToken']);
session_destroy();
}
$_SESSION['message'] = "Logged Out Sucessfully";
header("Location: login.php");
exit(0);
// session_start();
//  session_destroy();
//  header("location:login.php");
?>