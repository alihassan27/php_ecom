<?php


$host ="localhost";
$username ="root";
$password ="";
$db ="ecom";


$con =mysqli_connect("$host","$username","$password","$db");

if($con){
    echo "";
}
else{
    echo "Not Connected";
}

?>
