<?php

include('authentication.php');

if(isset($_POST['id'])){

  if(isset($_FILES['image']['name']) && $_FILES['image']['name']!==''){
  
  $id = $_POST['id'];
  $category_id = $_POST['category_id'];
  $name=$_POST['name'];
  $slug=$_POST['slug'];
  $price=$_POST['price'];
  $description=$_POST['description'];
  $meta_title= $_POST['meta_title'];
  $meta_description=$_POST['meta_description'];
  $meta_keyword = $_POST['meta_keyword'];
  $status=($_POST['status']);
    // $id = $_POST['id'];

    $up_pro =mysqli_query($con, "UPDATE `product` SET `category_id` = '$category_id', `name`='$name',`slug`='$slug', `price`='$price',
    `description`='$description',`image`= '$file_name',`meta_title`='$meta_title',`meta_description`='$meta_description',
    `meta_keyword`='$meta_keyword',`status`='$status' WHERE `id`='$id'" );
  
  $file_name = $_FILES['image']['name'];
  $file_type = $_FILES['image']['type']; 
  $file_size = $_FILES['image']['size']; 
  $file_tmp = $_FILES['image']['tmp_name']; 

    move_uploaded_file($file_tmp,'images/product/'.$file_name);
    if (empty($errors) == true) {
      move_uploaded_file($file_tmp, "images/product/" . $file_name);
      $iq=mysqli_query($con,"UPDATE `product` SET `image`='$file_name' WHERE `id`='$id' ");
      header('Location:view_product.php');
  }

  
} 
else{
  $id = ($_POST['id']);
  $category_id = $_POST['category_id'];
  $name=$_POST['name'];
  $slug=$_POST['slug'];
  $price=$_POST['price'];
  $description=$_POST['description'];
  $meta_title= $_POST['meta_title'];
  $meta_description=$_POST['meta_description'];
  $meta_keyword = $_POST['meta_keyword'];
  $status=($_POST['status']);
  $up_pro =mysqli_query($con, "UPDATE `product` SET `category_id` = '$category_id', `name`='$name',`slug`='$slug', `price`='$price',
  `description`='$description',`meta_title`='$meta_title',`meta_description`='$meta_description',
  `meta_keyword`='$meta_keyword',`status`='$status' WHERE `id`='$id'" );
  header('Location:view_product.php');
}

}
?>