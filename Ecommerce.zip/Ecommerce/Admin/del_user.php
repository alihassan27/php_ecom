<?php

include('authentication.php');

    $id = $_GET["id"];
    $query = "DELETE FROM `user` WHERE `id` = '$id'";
    $res = mysqli_query($con, $query);
    if($res){
        echo "DELETED";
        header("Location: view_user_register.php");
    }
    else{
        $_SESSION ['message'] = "Deleted Sucessfully!";
        header("location: view_user_register.php");
        exit(0);
    }


?>
