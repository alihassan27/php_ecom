<?php

include('authentication.php');

if (isset($_POST['add_btn'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role_as = $_POST['role_as'];
    $status = $_POST['status'] == true ? '1' : '0';

        // check email

        $checkemail = "SELECT email FROM user WHERE email='$email'";

        $checkemail_run = mysqli_query($con, $checkemail);

        if (mysqli_num_rows($checkemail_run) > 0) {

            // already emial exist
            $_SESSION['message'] = "Email already exist";

            header("Location: add_user.php");
            exit(0);
        }
        else{
            $add_query = "INSERT INTO user (username, email , password ,status, role_as) VALUES ('$username','$email','$password','$status','$role_as')"; 
            $query = mysqli_query($con, $add_query);
        }
    if($query){
        $_SESSION ['message'] = "User/Admin Added Sucessfully";
        header("location: view_user_register.php");
        exit(0);
    }
    else{
        $_SESSION ['message'] = "Opps! Error";
        header("location: view_user_register.php");
        exit(0);
    }
}

?>