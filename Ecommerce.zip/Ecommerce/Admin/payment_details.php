<?php
include('authentication.php');
include('includes/header.php');
?>

<head>
    <link href="">
</head>

<div class="row my-4">
    <div class="col-md-11 mx-auto">
        <div class="card">
            <div class="card-header">
            <div class="row card-header m-0">
            <div class="col-md-6">
            <h2>Paypal Order Details</h2>
            </div>
            <div class="col-md-6">
            <!-- <a href="add_product.php" class="btn btn-primary float-end"><i class="fa fa-plus"></i> Add</a> -->
            </div>
            </div>


            <div class="card-body">

                <div class="table-responsive">
                    <table class="table table-bordered table-stripe">
                        <thead class="thead-light">
                            <tr>
                                <th>Payment ID</th>
                                <th>Item Number</th>
                                <th>Txn ID</th>
                                <th>Payment Gross</th>
                                <th>Currency Code</th>
                                <th>Payment Status</th> 
                                <th>Delivered</th>
                                <!-- <th>Action</th> -->
                            </tr>
                        </thead>

                        <tbody>

                            <?php                  
                            $view_pro = mysqli_query($con, "SELECT * FROM payments");
                            while ($vq_row = mysqli_fetch_array($view_pro)) {
                            ?>
                                <tr>
                                    <td><?= $vq_row['payment_id']; ?></td>
                                    <td><?= $vq_row['item_number'] ?></td>
                                    <td><?= $vq_row['txn_id']; ?></td>
                                    <td><?= $vq_row['payment_gross'] ?></td>
                                    <td><?= $vq_row['currency_code'] ?></td>
                                    <td><?= $vq_row['payment_status'] ?></td>
                                    <td>
                                        <?php 
                                        if($vq_row['delivered'] == 1){
                                            echo '<p class="btn btn-warning"><a href="delivered.php?payment_id='.$vq_row['payment_id'].'&delivered=0">Yes</p>';
                                        }
                                        else{
                                            echo '<p class="btn btn-info"><a href="delivered.php?payment_id='.$vq_row['payment_id'].'&delivered=1">No</p>';
                                        }
                                         ?>
                                    </td>

                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>

                    </table>
                </div>


            </div>
        </div>
    </div>
</div>
</div>
<?php
    include('includes/footer.php');
    include('includes/scripts.php');
    ?>