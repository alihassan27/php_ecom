<?php

include('authentication.php');

if(isset($_POST['add_pro'])){

    $category_id = $_POST['category_id'];
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    $file_name = $_FILES['image']['name'];
    $file_type = $_FILES['image']['type']; 
    $file_size = $_FILES['image']['size']; 
    $file_tmp = $_FILES['image']['tmp_name']; 
    move_uploaded_file($file_tmp,'images/product/'.$file_name);

    if (empty($errors) == true) {
        move_uploaded_file($file_tmp, "images/product/" . $file_name);
    } else {
        echo "Something Went Wrong";
    }
    $meta_title = $_POST['meta_title'];
    $meta_description = $_POST['meta_description'];
    $meta_keyword = $_POST['meta_keyword'];
    $status = $_POST['status']==true? '1':'0';
  

    $query = mysqli_query($con,"INSERT INTO `product`(`category_id`,`name`,`slug`,`price`,`image`,`description`,`meta_title`,`meta_description`,`meta_keyword`,`status`)
    VALUES('$category_id','$name','$slug','$price','$file_name','$description','$meta_title','$meta_description','$meta_keyword','$status')");
    $_SESSION['message'] = 'Done Successfully';
    header('Location:view_product.php');
    exit(0);
}


?>