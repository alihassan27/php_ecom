<?php
include('authentication.php');

include('includes/header.php');
?>






<div class="container-fluid px-4">
    <h1 class="mt-4">Edit Users</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
        <li class="breadcrumb-item active">Users</li>

    </ol>
    
    <?php
    include('message.php');
    ?>

    <div class="row">

    <?php
    $user_id = $_GET["id"];
    $qu = "SELECT * FROM `user` WHERE `id`='$user_id'";
    $res = mysqli_query($con, $qu);
    $user = mysqli_fetch_array($res);
    ?>    
        <form action="update_usercode.php" method="POST" >
            <input type="hidden" name="user_id" value="<?= $user['id']; ?>"> 
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="">Name</label>
                    <input type="text" name="username" value="<?= $user['username']; ?>" class="form-control">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Email</label>
                    <input type="text" name="email" value="<?= $user['email']; ?>" class="form-control">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Password</label>
                    <input type="text" name="password" value="<?= $user['password']; ?>" class="form-control">
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="">Role as</label>
                    <select name="role_as" class=form-control value="<?= $user['role_as']; ?>">
                        <option value="">Select Role</option>
                        <option value="1" <?= $user['role_as'] == '1' ? "Selected":" "; ?>>Admin</option>
                        <option value="0"<?= $user['role_as'] == '0' ? "Selected":" "; ?>>User</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Status</label>
                    <input type="checkbox" name="status"  value="<?= $user['status'] == '1' ? "checked" : ""?>"   width="70px" height="70px">
                </div>                
                <div class="col-md-12 mb-3">
                    <button class="btn btn-primary" name="update_btn">Update User</button>
                </div>
            </div>
        </form>
        

    </div>

<?php
include('includes/footer.php');
include('includes/scripts.php');
?>    