<?php

include('authentication.php');

if(isset($_POST['id'])){
  $id = ($_POST['id']);
  $name=mysqli_real_escape_string($con,$_POST['name']);
  $slug=mysqli_real_escape_string($con,$_POST['slug']);
  $description=mysqli_real_escape_string($con,$_POST['description']);
  $meta_title=mysqli_real_escape_string($con,$_POST['meta_title']);
  $meta_description=mysqli_real_escape_string($con,$_POST['meta_description']);
  $meta_keyword=mysqli_real_escape_string($con,$_POST['meta_keyword']);
  $navbar_status=($_POST['navbar_status']);
  $status=($_POST['status']);

  $uq_cat=mysqli_query($con,"UPDATE `categories` SET `name`='$name',`slug`='$slug',
  `description`='$description',`meta_title`='$meta_title',`meta_description`='$meta_description',
  `meta_keyword`='$meta_keyword',`navbar_status`='$navbar_status',`status`='$status'
  WHERE `id`='$id'" );
  header('Location:view_category.php');
}else{
    echo  "Not Found";
}
?>