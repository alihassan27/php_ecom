<?php
include('config/connection.php');
$id= $_GET['stripe_id'];
$delivered = $_GET['delivered'];
$q = "UPDATE stripe_payments SET delivered = $delivered where stripe_id = $id";
mysqli_query($con, $q);
header("location: stripe_payments.php");
?>