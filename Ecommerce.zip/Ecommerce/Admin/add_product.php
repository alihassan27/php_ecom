<?php
include('authentication.php');
include('includes/header.php');
?> 

<!-- form card -->

<div class="row my-4">
    <div class="col-md-11 mx-auto">
     
        <div class="card">
            <div class="row card-header m-0">
            <div class="col-md-6">
            <h2>Add Prodcuts</h2>
            </div>
            <div class="col-md-6">
            <a href="view_product.php" class="btn btn-danger float-end"><i class="fa fa-arrow-left"></i> Back</a>
            </div>
            </div>
           
            <div class="card-body">
                <form action="add_productcode.php" enctype="multipart/form-data" method="POST">
                    <div class="row">
        <?php
        include('message.php');
        ?>
                        <div class="col-md-6 mb-3">
                            <label> Name</label>
                            <input type="text" name="name" required class="form-control">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label>Slug(url)</label>
                            <input type="text" name="slug" required class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label> Price</label>
                            <input type="text" name="price" required class="form-control">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label>Description</label>
                            <textarea name="description" max="100" rows="1" required class="form-control"></textarea>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label>Image</label>
                            <input type="file" name="image"  class="form-control">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label>Meta Title</label>
                            <textarea name="meta_title" required rows="1" class="form-control"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Meta Description</label>
                            <textarea name="meta_description" required class="form-control" rows="1"></textarea>

                        </div>

                        <div class="col-md-6 mb-3">
                            <label>Meta Keyword</label>
                            <textarea name="meta_keyword" required class="form-control" rows="1"></textarea>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="">Category</label>
                            <?php
							$sql= "select * from categories";
                   $result = mysqli_query($con,$sql);
							if ($result->num_rows > 0) { 
                ?>

                            <select name="category_id" class="form-control" id="">
                                <option value="">Select Category</option>
                                <?php
							    // output data of each row
							    while($row = $result->fetch_assoc()) { ?>
									<option value="<?php echo $row["id"]; ?>"><?php echo $row["name"]; ?></option>
									<?php 
							    } ?>
</select>
<?php 
						} ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="">status</label>
                            <input type="checkbox" name="status">
                        </div>


                        <div class="col-md-12 mb-3">
                            <button type="submit" name="add_pro" class="btn btn-primary">Add Product</button>

                        </div>

                    </div>

            </div>
            </form>



            <?php
            include('includes/footer.php');
            include('includes/scripts.php');
            ?>