<?php

include('authentication.php');
include('includes/header.php');

?>







<!-- form card -->

<div class="row">
    <div class="col-md-12">

        <?php
        $cid = $_REQUEST['id'];
        $edq_cid = mysqli_query($con, "SELECT * FROM `categories` WHERE `id`='$cid'");
        $crow_cid = mysqli_fetch_array($edq_cid);
        ?>

        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-6">
                        <h3>Edit category</h3>
                    </div>

                    <div class="col-6">
                        <a href="view_category.php" class="btn btn-primary float-end">view category</a>
                    </div>
                </div>

            </div>


            <div class="card-body">
                <form action="update_cat_code.php" method="POST">
               
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label> Name</label>
                        
                            <input type="hidden" name="id" class="txtField" value="<?= $crow_cid['id']; ?>">

                            <input type="text" name="name" value="<?=$crow_cid['name'];?>"  required class="form-control">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label>Slug(url)</label>
                            <input type="text" name="slug" value="<?= $crow_cid['slug'];?>" required class="form-control">
                        </div>

                        <div class="col-md-12 mb-3">
                            <label>Description</label>
                            <textarea name="description"  max="190" required class="form-control"><?=$crow_cid['description'];?></textarea>
                        </div>

                        <div class="col-md-12 mb-3">
                            <label>Meta title</label>
                            <textarea name="meta_title"  required class="form-control"><?=$crow_cid['meta_title'];?></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Meta Description</label>
                            <textarea name="meta_description"  required class="form-control" rows="4"><?=$crow_cid['meta_description'];?></textarea>

                        </div>

                        <div class="col-md-6 mb-3">
                            <label>Meta Keyword</label>
                            <textarea name="meta_keyword"  required class="form-control" rows="4"><?=$crow_cid['meta_keyword'];?></textarea>
                        </div>


                        <div class="col-md-6 mb-3">
                            <label for="">Navbar status</label>
                            <input type="checkbox" name="navbar_status" value="<?=$crow_cid['navbar_status']=='1'? 'Visible':'Hidden'?>">

                        </div>


                        <div class="col-md-6 mb-3">
                            <label for="">status</label>
                            <input type="checkbox" name="status" value="<?= $crow_cid['status']=='0'? 'checked':''?>" >

                        </div>

                        <div class="col-md-6 mb-3">
                            <button type="submit" name="update-category" class="btn btn-primary" >Update Category</button>

                        </div>

                    </div>

                </form>
            </div>



            <?php
            include('includes/footer.php');
            include('includes/scripts.php');
            ?>