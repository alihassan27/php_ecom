<?php

include('authentication.php');
include('includes/header.php');

// echo "<pre>";
// print_r($_SESSION);
// echo "</pre>";
// die();

?>






<!-- form card -->
<!-- <?php
// if (isset($_REQUEST['deleted'])) {
//     echo $deleted;
// }
// if (isset($_REQUEST['completed'])) {
//     echo $completed;
// }
// if (isset($_REQUEST['updated'])) {
//     echo $updated;
// }
?> -->
<div class="row">
    <div class="col-md-12">

        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-6">
                        <h3>view categories</h3>
                    </div>

                    <div class="col-6">

                        <a href="add_category.php"><button class="btn btn-primary float-end">Add <i class="fa fa-plus float-right"></i></button></a>
                    </div>
                </div>

            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-stripe">
                        <thead class="thead-light">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Slug</th>
                                <!-- <th>Description</th>
                                <th>Meta_title</th>
                                <th>Meta_Description</th>
                                <th>Meta_Keyword</th> -->
                                <th>Navbar_status</th>
                                <th>Action</th>
                                <th>Action</th>
                            </tr>
                        </thead>


                        <tbody>

                            <?php

                            $viewque_cat = mysqli_query($con, "SELECT * FROM `categories` ORDER BY `id` ASC");
                            while ($row_cat = mysqli_fetch_array($viewque_cat)) {



                            ?>
                                <tr>
                                    <td><?= $row_cat['id']; ?></td>
                                    <td><?= $row_cat['name']; ?></td>
                                    <td><?= $row_cat['slug']; ?></td>
                                    <td><?php if($row_cat['navbar_status']==0){echo"visible";}if($row_cat['status']==1){echo"Hidden";} ?></td>
                                    <td> <a href="edit_category.php?id=<?=$row_cat['id'];?>"><button class="btn btn-primary"><i class="fa fa-pen"></i></button></a></td>
                                    <td> <a href="del_category.php?id=<?=$row_cat['id'];?>" onclick=" return confirm('Are you sure you want to delete?')"><button class="btn btn-danger"><i class="fa fa-trash"></i></button></a></td>
                                   

                                </tr>
                            <?php
                            

                            }

                            ?>
                        </tbody>

                    </table>
                </div>



            </div>
        </div>
    </div>
</div>


<?php
include('includes/footer.php');
include('includes/scripts.php');
?>