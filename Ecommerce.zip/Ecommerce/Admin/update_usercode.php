<?php

include('authentication.php');

if (isset($_POST['update_btn'])) {
    // echo"<pre>";
    // print_r($_POST);
    // echo"</pre>";
    // exit();
    $user_id = $_POST['user_id'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role_as = $_POST['role_as'];
    $status = $_POST['status'] == true ? '1' : '0';

        // check email

        // $checkemail = "SELECT email FROM user WHERE email='$email'";

        // $checkemail_run = mysqli_query($con, $checkemail);

        // if (mysqli_num_rows($checkemail_run) > 0) {

        //     // already emial exist
        //     $_SESSION['message'] = "Email already exist";
        //     header("Location: edit_user.php");
        //     exit(0);
        // }
        // else{}

    $up_query = "UPDATE `user` SET `username` = '$username',`email`='$email',`password` = '$password', 
    `role_as` = '$role_as' WHERE `id` = '$user_id' ";
        
    $query = mysqli_query($con,$up_query);
    if($query){
        $_SESSION ['message'] = "Data Updated Sucessfully";
        header("location: view_user_register.php");
        exit(0);
    }
    else{
        $_SESSION ['message'] = "Opps! Error";
        header("location: view_user_register.php");
        exit(0);
    }
}

?>

<!-- echo"<pre>";
print_r($_POST);
echo"</pre>"; -->