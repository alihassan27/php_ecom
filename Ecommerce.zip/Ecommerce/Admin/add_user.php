<?php

include('authentication.php');

include('includes/header.php');
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Add User/Admin</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
        <li class="breadcrumb-item active">Users/Admins</li>
    </ol>

    <?php
    include('message.php');
    ?>

    <div class="row">
    <div class="col-md-2 mb-3">
        <a href="view_user_register.php" class="btn btn-danger"><i class="fa fa-arrow-left"></i>Back</a>
        </div>
        <form action="add_usercode.php" method="POST">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="">Name</label>
                    <input type="text" name="username" class="form-control">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Email</label>
                    <input type="text" name="email" class="form-control">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Password</label>
                    <input type="text" name="password" class="form-control">
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="">Role as</label>
                    <select name="role_as" class=form-control>
                        <option value="">Select Role</option>
                        <option value="1">Admin</option>
                        <option value="0">User</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Status</label>
                    <input type="checkbox" name="status" width="70px" height="70px">
                </div>                
                <div class="col-md-12 mb-3">
                    <button class="btn btn-primary" name="add_btn">Add</button>
                </div>
            </div>
        </form>
        

    </div>

<?php
include('includes/footer.php');
include('includes/scripts.php');
?>    