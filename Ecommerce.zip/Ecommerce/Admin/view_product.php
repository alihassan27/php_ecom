<?php
include('authentication.php');
include('includes/header.php');
?>


<div class="row my-4">
    <div class="col-md-11 mx-auto">
        <div class="card">
            <div class="card-header">
            <div class="row card-header m-0">
            <div class="col-md-6">
            <h2>View Prodcuts</h2>
            </div>
            <div class="col-md-6">
            <a href="add_product.php" class="btn btn-primary float-end"><i class="fa fa-plus"></i> Add</a>
            </div>
            </div>


            <div class="card-body">

                <div class="table-responsive">
                    <table class="table table-bordered table-stripe">
                        <thead class="thead-light">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Price</th>
                                <th>Description</th>
                                <th>Image</th> 
                                <th>Status</th>
                                <th>Action</th>
                                <th>Action</th>
                            </tr>
                        </thead>


                        <tbody>

                            <?php                  
                            $view_pro = mysqli_query($con, "SELECT p.*, c.name AS cname FROM product p, categories c WHERE  c.id = p.category_id");
                            while ($vq_row = mysqli_fetch_array($view_pro)) {

                            ?>


                                <tr>
                                    <td><?= $vq_row['id']; ?></td>
                                    <td><?= $vq_row['name'] ?></td>
                                    <td><?= $vq_row['cname']; ?></td>
                                    <td><?= $vq_row['price'] ?></td>
                                    <td><?= $vq_row['description'] ?></td>
                                    <td><img src="images/product/<?= $vq_row['image']; ?>" alt="" height="80" width="80" ;></td>
                                    <td><?php if ($vq_row['status'] == 0) {
                                            echo "visible";
                                        }
                                        if ($vq_row['status'] == 1) {
                                            echo "Hidden";
                                        } ?></td>
                                    <td> <a href="edit_product.php?id=<?= $vq_row['id'] ?>"><button class="btn btn-primary"> <i class="fa fa-pen"></i></button></a></td>
                                    <td> <a href="del_product.php?id=<?= $vq_row['id']; ?>" onclick=" return confirm('Are you sure you want to delete?')"><button class="btn btn-danger"> <i class="fa fa-trash"></i></button></a></td>



                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>

                    </table>
                </div>


            </div>
        </div>
    </div>
</div>
</div>
<?php
    include('includes/footer.php');
    include('includes/scripts.php');
    ?>