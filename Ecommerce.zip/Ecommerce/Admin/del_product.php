<?php

include('authentication.php');

$id = $_GET['id'];

// for img del

$pro_q = mysqli_query($con, "SELECT * FROM `product` WHERE `id`='$id'");
$row = mysqli_fetch_assoc($pro_q);
unlink("images/product/" . $row['image']);


$query = mysqli_query($con, "DELETE FROM `product` WHERE `id`='$id'");
header('Location: view_product.php');
?>