<?php
include('authentication.php');

include('includes/header.php');
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Users</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
        <li class="breadcrumb-item active">Users</li>

    </ol>

    <div class="row">
        <?php
        include('message.php');
        ?>
        <div class="col-md-12">
            <div class="card">
                <div class="row card-header m-0">
                <div class="col-6">
                    <h4>Registered Users</h4>
                </div>
                <div class="col-6">
                <a href="add_user.php" class="btn btn-primary float-end">Add User/Admin</a>
                </div>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>email</th>
                                <th>password</th>
                                <th>status</th>
                                <th>role_as</th>
                                <th colspan="2" class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM user ";
                            $query_run = mysqli_query($con, $query);
                            if(mysqli_num_rows($query_run) > 0)
                            {
                                foreach($query_run as $row)
                                {
                            ?>
                            <tr>
                                <td><?= $row['id'] ?></td>
                                <td><?= $row['username'] ?></td>
                                <td><?= $row['email'] ?></td>
                                <td><?= $row['password'] ?></td>
                                <td><?= $row['status'] ?></td>
                                
                                <td>
                                    <?php
                                    if($row['role_as']== '1'){
                                        echo 'Admin';
                                    }
                                    elseif($row['role_as']== '0'){
                                        echo 'User';
                                    }
                                    ?>
                                </td>
                                <td><a href="edit_user.php?id=<?= $row['id']; ?>" name="btn_edit" class="btn btn-primary"><i class="fa fa-pen"></a></td></i>

                                <td>
                                    <!-- <button type="submit" name="btn_del" value="del_user.php<?= $row['id']; ?>" onclick="return confirm('Are You Sure?')" class="btn btn-danger">
                                    <i class="fa fa-trash"></button></td></i> -->
                                <a href="del_user.php?id=<?= $row['id']; ?>"  onclick="return confirm('Are You Sure, You want to Delete?')" name="btn_del" class="btn btn-danger"><i class="fa fa-trash"></a></td></i>
                            </tr>
                            <?php
                            
                        }
                    }
                    else
                    {
                        ?>
                        <tr>
                        <td colspan="6">No Record Found</td>
                        </tr>
                        <?php
                    }
                    ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php
    include('includes/footer.php');
    include('includes/scripts.php');
    ?>