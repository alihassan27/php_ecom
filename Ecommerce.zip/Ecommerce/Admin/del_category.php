<?php

include('authentication.php');

    $id = $_GET["id"];
    $query = "DELETE FROM `categories` WHERE `id` = '$id'";
    $res = mysqli_query($con, $query);
    if($res){
        echo "DELETED";
        header("Location: view_category.php");
    }
    else{
        $_SESSION ['message'] = "Not Deleted Sucessfully!";
        header("location: view_user_register.php");
        exit(0);
    }


?>
