<?php
include('config/connection.php');
$id= $_GET['payment_id'];
$delivered = $_GET['delivered'];
$q = "UPDATE payments SET delivered = $delivered where payment_id = $id";
mysqli_query($con, $q);
header("location: payment_details.php");
?>