<?php
include('authentication.php');
include('includes/header.php');

if(isset($_SESSION['auth_user']['user_id'])){
        $s_query = mysqli_query($con, "SELECT * FROM user where `id`='{$_SESSION['auth_user']['user_id']}'");
        while($s_row = mysqli_fetch_array($s_query)){
    ?>
        <div class="col-md-6 my-5 bg-dark text-white p-5 mx-auto">
            <table class="table table-bordered">
                <thead class="text-bold"><b>Admin Details:</b></thead>
                <tbody>
                    <tr class="text-white">
                    <th>Name:</th>
                    <th>Email:</th>
                    </tr>
                    <tr  class="text-white">
                        <td><?= $s_row['username']; ?></td>
                        <td> <?= $s_row['email']; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <?php
        }
    }
        ?>