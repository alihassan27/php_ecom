<?php
include('authentication.php');
include('includes/header.php');
?> 

<!-- form card -->

<div class="row my-4">

<div class="col-md-11 mx-auto">
     
        <div class="card">
            <div class="row card-header m-0">
            <div class="col-md-6">
            <h2>Edit Prodcuts</h2>
            </div>
            <div class="col-md-6">
            <a href="view_product.php" class="btn btn-danger float-end"><i class="fa fa-arrow-left"></i> Back</a>
            </div>
            </div>
            <?php
$id = $_GET['id'];
$pro_query = mysqli_query($con, "SELECT * FROM `product` WHERE id='$id'");
$pro_row = mysqli_fetch_array($pro_query);

?>
            
            <div class="card-body">
                <form action="up_pro.php" enctype="multipart/form-data" method="POST">
                    <input type="hidden" name="id" value="<?= $pro_row['id']; ?>">                    
                    <input type="hidden" name="oldPath" value="<?= $pro_row['image']; ?>">                    
                    <div class="row">

                        <div class="col-md-6 mb-3">
                            <label> Name</label>
                            <input type="text" name="name" value="<?= $pro_row['name']; ?>" required class="form-control">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label>Slug(url)</label>
                            <input type="text" name="slug" value="<?= $pro_row['slug']; ?>" required class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label> Price</label>
                            <input type="text" name="price" value="<?= $pro_row['price']; ?>" required class="form-control">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label>Description</label>
                            <textarea name="description" max="100" rows="1" required class="form-control"><?= $pro_row['description']; ?></textarea>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label>Image</label>

                            <img src="images/product/<?= $pro_row['image']; ?>" alt="" height="80" width="80" ;>
                            <div class="input-group mb-4">
                                <br>
                            <input type="file" name="image"  class="form-control">

                            </div>
                            
                        </div>

                        <div class="col-md-6 mb-3">
                            <label>Meta Title</label>
                            <textarea name="meta_title" required rows="1" class="form-control"><?= $pro_row['description']; ?></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Meta Description</label>
                            <textarea name="meta_description" required class="form-control" rows="1"><?= $pro_row['description']; ?></textarea>

                        </div>

                        <div class="col-md-6 mb-3">
                            <label>Meta Keyword</label>
                            <textarea name="meta_keyword" required class="form-control" rows="1"><?= $pro_row['meta_keyword']; ?></textarea>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="">Category</label>
                            <?php
							$sql= "select * from categories";
                   $result = mysqli_query($con,$sql);
							if ($result->num_rows > 0) { 
                ?>

                            <select name="category_id" class="form-control" id="">
                                <option value="">Select Category</option>
                                <?php
							    // output data of each row
							    while($row = $result->fetch_assoc()) { ?>
									<option value="<?php echo $row["id"]; ?>" <?= $row['id'] == $pro_row['category_id'] ? 'selected' : '' ?> ><?php echo $row["name"]; ?></option>
									<?php 
							    } ?>
</select>
<?php 
						} ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="">status</label>
                            <input type="checkbox" name="status" value="<?= $pro_row['status']=='0'? 'checked':''?>" >
                        </div>


                        <div class="col-md-12 mb-3">
                            <button type="submit" name="edit_pro" class="btn btn-primary">Edit Prodcut</button>

                        </div>

                    </div>

            </div>
            </form>



            <?php
            include('includes/footer.php');
            include('includes/scripts.php');
            ?>