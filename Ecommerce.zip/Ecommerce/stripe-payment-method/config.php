<?php
require('stripe-php-master/init.php');

$publishableKey="pk_test_51LuwsHIhPAni9VP1hThfqaycHH8W47kYfxF27lBTWm5JKixjKCtUVy2YzaSqRmGAYGSSNLCv8zmWEuoNHQAgrJRX00YSdJFjZm";

$secretKey="sk_test_51LuwsHIhPAni9VP1mYWRG5mSMQy8Du5DUHxIfbyxkJgA6bLw2aWgJPqdkweVXDgfMbj9pIBCgIajORLXGx4tI5c400FUAreufA";

\Stripe\Stripe::setApiKey($secretKey);
?>