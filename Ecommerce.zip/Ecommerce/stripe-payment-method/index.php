<?php
require('config.php');
?>
<form action="submit.php" method="post">
	<script
		src="https://checkout.stripe.com/checkout.js" class="stripe-button"
		data-key="<?php echo $publishableKey?>"
		data-amount="1000"
		data-name="Programming with Ali Hassan"
		data-description="Programming with Ali Hassan Desc"
		data-image="https://t3.ftcdn.net/jpg/04/89/23/50/360_F_489235014_Uudpk9ACCCbUK29ZyxhBUejBqLMSEj6d.jpg"
		data-currency="usd"
	>
	</script>
			<!-- data-email="alihassan.lancer@gmail.com" -->

</form>