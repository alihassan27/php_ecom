<?php
require('config.php');
include('../config/connection.php');
include "../paypal/forgot/mail.php";

session_start();
if (isset($_POST['stripeToken'])) {
	\Stripe\Stripe::setVerifySslCerts(false);

	$token = $_POST['stripeToken'];
	if (isset($_POST['stripeToken'])) {
		// echo "<pre>";
		// print_r($_POST);
		// echo "</pre>";
		// die();
		$item_number = $_POST['item_number'];
		$amount = $_POST['amount'];
		$stripe_Token = $_POST['stripeToken'];
		$stripe_Token_Type = $_POST['stripeTokenType'];
		$payment_status = 'Completed';
		$query = mysqli_query($con, "INSERT INTO `stripe_payments`( `payment_gross`,`item_number`, `stripeToken`, `stripeTokenType`, `payment_status`)
		 VALUES ('$amount','$item_number','$stripe_Token','$stripe_Token_Type','$payment_status')");
		header('Location: ../view_cart.php');
		$user_id = $_SESSION['auth_user']['user_id'] ?? $_SESSION['auth_user']['fb_user_id'] ?? $_SESSION['google_id'];
		$del_query = mysqli_query($con, "DELETE FROM cart WHERE `user_id` = '$user_id'");
		$del_query = mysqli_query($con, "DELETE FROM cart WHERE `fb_user_id` = '$user_id'");
		$del_query = mysqli_query($con, "DELETE FROM cart WHERE `google_user_id` = '$user_id'");
	}
	else {
		echo "Not Working";
	}
}

// if(isset($_POST['stripeToken'])){
// 	\Stripe\Stripe::setVerifySslCerts(false);

// 	$token=$_POST['stripeToken'];

// 	$data=\Stripe\Charge::create(array(
// 		"amount"=>1000,
// 		"currency"=>"usd",
// 		"description"=>"Programming with Ali Hassan Desc",
// 		"source"=>$token,
// 	));

// 	echo "<pre>";
// 	print_r($data);
// }
?>

<?php
        //  while ($pRow = mysqli_fetch_array($productResult))

         $productResult = $con->query("SELECT * FROM stripe_payments");
         $pRow = $productResult->fetch_assoc();       
            $message .=  '<p><b>Reference Number:</b>'. $pRow['item_number'] .'</p>';
            $message .=  '<p><b>Transaction ID:</b>'. $pRow['stripeToken'] .'</p>';
            $message .=  '<p><b>Paid Amount:</b>'. $pRow['payment_gross'] .'</p>';
            send_mail("alihassan.lancer@gmail.com","Your Order Sucessfully Done", $message);
?>