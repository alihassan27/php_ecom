<?php
session_start();
include("config/connection.php");
include("includes/header.php");
?>

<body class="sub_page">

    <div class="hero_area">
        <div class="bg-box">
            <img src="assets/images/hero-bg.jpg" alt="">
        </div>
        <!-- header section strats -->
        <header class="header_section">
            <div class="container">
                <nav class="navbar navbar-expand-lg custom_nav-container ">
                    <a class="navbar-brand" href="index.php">
                        <span>
                            Feane
                        </span>
                    </a>

                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class=""> </span>
                    </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav  mx-auto ">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php">Home </a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="product_show.php">Products</a>
                            </li>

                            <li class="btn-group">
                                <button type="button" style="border-radius: 60px;" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">


                                    <?php

                                      if (isset($_SESSION['auth_user']['username'])) {
                                    
                                      ?>

                                      <?= $_SESSION['auth_user']['username']; ?>
                                      <?php
                                      }elseif(isset($_SESSION['auth_user']['fbUserName'])){
                                        ?>
                                        <?= $_SESSION['auth_user']['fbUserName']; ?>
                                    <?php
                                        }elseif(isset($_SESSION['user_first_name'])){
                                      ?>
                                        <?= $_SESSION['user_first_name']; ?>  
                                    <?php
                                    }
                                        else {
                                        echo "Login First";
                                      }
                                  
                                    ?>

                                </button>
                                    <?php
                                    if (isset($_SESSION['auth_user']['username'])) {
                                      ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="user_profile.php">My Profile</a>
                                    
                                      <form action="logout.php" method="POST" style="font-size: 20px;">
                                        <button type="submit" name="btn_logout" style="width: 10rem; border:none; background-color:transparent; color:white">Logout</button>
                                      </form>
                                    </div>              
                                    <?php
                                    }elseif(isset($_SESSION['auth_user']['fbUserName'])){             
                                    ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                  <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="user_profile.php">My Profile</a>

                                      <form action="logout.php" method="POST" style="font-size: 20px;">
                                        <button type="submit" name="btn_logout" style="width: 10rem; border:none; background-color:transparent; color:white">Logout</button>
                                      </form>
                                    </div>
                                    <?php
                                        }elseif(isset($_SESSION['user_first_name'])){             
                                        ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="user_profile.php">My Profile</a>

                                      <form action="logout.php" method="POST" style="font-size: 20px;">
                                        <button type="submit" name="btn_logout" style="width: 10rem; border:none; background-color:transparent; color:white">Logout</button>
                                      </form>
                                    </div>                                                                           
                                    <?php 
                                     }
                                     else{
                                    ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="login.php">Login</a>
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="Registration.php">Register Yourself</a>
                                    </div>              
                                    <?php
                                    }
                                    ?>
                            </li>
                        </ul>
                        <div class="user_option">
                            <a href="registration.php" class="user_link">
                                <i class="fa fa-user" aria-hidden="true"></i>
                            </a>
                            <?php
                                if (isset($_SESSION['auth_user']['user_id'])) {
                                    $cart_count = mysqli_query($con, "SELECT * FROM `cart` WHERE user_id='{$_SESSION['auth_user']['user_id']}'");
                                    $cart_rows = mysqli_num_rows($cart_count);
                                } elseif (isset($_SESSION['auth_user']['fb_user_id'])) {
                                    $cart_count = mysqli_query($con, "SELECT * FROM `cart` WHERE fb_user_id='{$_SESSION['auth_user']['fb_user_id']}'");
                                    $cart_rows = mysqli_num_rows($cart_count);
                                } elseif (isset($_SESSION['google_id'])) {
                                    $cart_count = mysqli_query($con, "SELECT * FROM `cart` WHERE google_user_id='{$_SESSION['google_id']}'");
                                    $cart_rows = mysqli_num_rows($cart_count);
                                } else {
                                    $cart_rows = '';
                                }
                                ?>
                                <?php
                                if (isset($_SESSION['auth_user']['user_id'])) {

                                ?>
                                    <a href="view_cart.php" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span class="bg-danger" style="padding: 5px; border-radius: 50%;font-size: 9px; position: absolute; top: 10px;"><?php echo $cart_rows  ?></span></i>
                                    </a>

                                <?php
                                } elseif (isset($_SESSION['auth_user']['fb_user_id'])) {
                                ?>
                                    <a href="view_cart.php" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span class="bg-danger" style="padding: 5px; border-radius: 50%;font-size: 9px; position: absolute; top: 10px;"><?php echo $cart_rows  ?></span></i>
                                    </a>
                                <?php
                                } elseif ( isset($_SESSION['google_id'])) {
                                ?>
                                    <a href="view_cart.php" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span class="bg-danger" style="padding: 5px; border-radius: 50%;font-size: 9px; position: absolute; top: 10px;"><?php echo $cart_rows  ?></span></i>
                                    </a>

                                <?php
                                } else {
                                ?>
                                    <a href="*" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span></span></i>
                                    </a>
                                <?php
                                }
                                ?>

                        </div>
                    </div>
                </nav>
            </div>
        </header>
        <!-- end header section -->
    </div>

    <!-- food section -->



    <section class="food_section layout_padding">
        <div class="container">

            <div class="heading_container heading_center">
                <h2>
                    Our Menu
                </h2>
            </div>





            <div class="filters-content">


                <div class="row grid">

                     <?php
                    //  if(isset($_POST['cat']))
                    //  {
                    //  $slug = mysqli_real_escape_string($con, $_POST['cat']);
                    //  $cat_query = "SELECT * FROM categories WHERE $slug = slug";
                    //  $cat_query_run = mysqli_query($con, $cat_query);
                    //  if(mysqli_num_rows($cat_query_run) > 0)
                    //  {
                    //     $navItem = mysqli_fetch_array($cat_query_run);
                    //     $category_id = $navItem['id'];
                    //     $pro_qu =  "SELECT * FROM product WHERE category_id = $category_id";
                    //     $pro_run = mysqli_query($con, $pro_qu);
                            
                    //     if(mysqli_num_rows($pro_run) > 0)
                    //     {
                    //         foreach($pro_run as $vq_row)
                    //         {
                    //

                         $view_pro = mysqli_query($con, "SELECT p.*, c.name AS cname FROM product p, categories c WHERE  c.id = p.category_id");
                         while ($vq_row = mysqli_fetch_array($view_pro)) {
                     ?> 
                        <div class="col-sm-6 col-lg-4 all pizza">
                            <div class="box">
                                <div>
                                    <!-- <input type="show"  -->
                                    <div class="img-box">
                                        <img src="Admin/images/product/<?php echo $vq_row['image']; ?>" width="200" height="266" alt="">

                                    </div>
                                    <div class="detail-box">
                                        <h5>
                                            <?= $vq_row['name']; ?>
                                        </h5>    
                                        <p>
                                             <?= $vq_row['description']; ?>
                                        </p>
                                        <h6>
                                          <b class="text-primary">Category:</b> <?= $vq_row['cname']; ?>
                                        </h6>
                                        <!-- <div>
                                            <input type="number" name="quantity" placeholder="Select Quantity">
                                        </div> -->

                                        <div class="options">
                                            <h6>
                                               Price. <?= $vq_row['price'] .' $'; ?>
                                            </h6>
                                            <a href="product_details.php?id=<?= $vq_row['id']; ?>">
                                                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 456.029 456.029" style="enable-background:new 0 0 456.029 456.029;" xml:space="preserve">
                                                    <g>
                                                        <g>
                                                            <path d="M345.6,338.862c-29.184,0-53.248,23.552-53.248,53.248c0,29.184,23.552,53.248,53.248,53.248
                         c29.184,0,53.248-23.552,53.248-53.248C398.336,362.926,374.784,338.862,345.6,338.862z" />
                                                        </g>
                                                    </g>
                                                    <g>
                                                        <g>
                                                            <path d="M439.296,84.91c-1.024,0-2.56-0.512-4.096-0.512H112.64l-5.12-34.304C104.448,27.566,84.992,10.67,61.952,10.67H20.48
                         C9.216,10.67,0,19.886,0,31.15c0,11.264,9.216,20.48,20.48,20.48h41.472c2.56,0,4.608,2.048,5.12,4.608l31.744,216.064
                         c4.096,27.136,27.648,47.616,55.296,47.616h212.992c26.624,0,49.664-18.944,55.296-45.056l33.28-166.4
                         C457.728,97.71,450.56,86.958,439.296,84.91z" />
                                                        </g>
                                                    </g>
                                                    <g>
                                                        <g>
                                                            <path d="M215.04,389.55c-1.024-28.16-24.576-50.688-52.736-50.688c-29.696,1.536-52.224,26.112-51.2,55.296
                         c1.024,28.16,24.064,50.688,52.224,50.688h1.024C193.536,443.31,216.576,418.734,215.04,389.55z" />
                                                        </g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                    <g>
                                                    </g>
                                                </svg>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php    
                //     }
                //      }
                //      else{
                //         echo "Not Found";
                //      }

                //     }
                // }
                //     ?>


                 <?php
                     }
                    ?> 



                </div>

            </div>


        </div>
        <div class="btn-box">
            <a href="">
                View More
            </a>
        </div>
    </section>


    <?php
    include("includes/footer.php");
    include("includes/scripts.php");
?>
</body>
</html>
    
