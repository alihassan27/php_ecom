<?php

session_start();
include("config/connection.php");
include("includes/header.php");
include("Login-with-Facebook-using-PHP-SDK-master/fb-config.php");
include("googleapi/config.php");

?>
<body class="sub_page">

    <div class="hero_area">
        <div class="bg-box">
            <img src="assets/images/hero-bg.jpg" alt="">
        </div>
        <!-- header section strats -->
        <header class="header_section">
            <div class="container">
                <nav class="navbar navbar-expand-lg custom_nav-container ">
                    <a class="navbar-brand" href="index.php">
                        <span>
                            Feane
                        </span>
                    </a>

                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class=""> </span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav  mx-auto ">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php">Home </a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="product_show.php">Products</a>
                            </li>
                           // <?php
                           // $navbarCategory = "SELECT * FROM categories WHERE navbar_status='0' AND status='0' ";
                           // $navbar_run = mysqli_query($con, $navbarCategory);
                           // 
                           // if(mysqli_num_rows($navbar_run) > 0)
                           // {
                           //     foreach($navbar_run as $navItem)
                           //     {
                           //         ?>
                            <!-- <li class="nav-item">
                                <a class="nav-link" href="product_show.php?cat=<?= $navItem['slug']; ?>"><?= $navItem['name']; ?></a>
                            </li> -->
                           // <?php
                           //     }
                           // }
                           // 
                           // ?>

                            <li class="btn-group">
                                <button type="button" style="border-radius: 60px;" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">


                                    <?php

                                      if (isset($_SESSION['auth_user']['username'])) {
                                    
                                      ?>

                                      <?= $_SESSION['auth_user']['username']; ?>
                                      <?php
                                      }elseif(isset($_SESSION['auth_user']['fbUserName'])){
                                        ?>
                                        <?= $_SESSION['auth_user']['fbUserName']; ?>
                                    <?php
                                        }elseif(isset($_SESSION['user_first_name'])){
                                      ?>
                                        <?= $_SESSION['user_first_name']; ?>  
                                    <?php
                                    }
                                        else {
                                        echo "Login First";
                                      }
                                  
                                    ?>

                                </button>
                                    <?php
                                    if (isset($_SESSION['auth_user']['username'])) {
                                      ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                  <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="user_profile.php">My Profile</a>
                                    
                                      <form action="logout.php" method="POST" style="font-size: 20px;">
                                        <button type="submit" name="btn_logout" style="width: 10rem; border:none; background-color:transparent; color:white">Logout</button>
                                      </form>
                                    </div>              
                                    <?php
                                    }elseif(isset($_SESSION['auth_user']['fbUserName'])){             
                                    ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="user_profile.php">My Profile</a>

                                      <form action="logout.php" method="POST" style="font-size: 20px;">
                                        <button type="submit" name="btn_logout" style="width: 10rem; border:none; background-color:transparent; color:white">Logout</button>
                                      </form>
                                    </div>
                                    <?php
                                        }elseif(isset($_SESSION['user_first_name'])){             
                                        ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="user_profile.php">My Profile</a>

                                      <form action="logout.php" method="POST" style="font-size: 20px;">
                                        <button type="submit" name="btn_logout" style="width: 10rem; border:none; background-color:transparent; color:white">Logout</button>
                                      </form>
                                    </div>                                                                           
                                    <?php 
                                     }
                                     else{
                                    ?>
                                    <div class="dropdown-menu" style="font-size: 17px; background-color:#272c30; margin-left:25px;">
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="login.php">Login</a>
                                      <a class="dropdown-item" style="padding-left:40px; color:white; background-color:transparent;" href="Registration.php">Register Yourself</a>
                                    </div>              
                                    <?php
                                    }
                                    ?>
                            </li>

                        </ul>
                        <div class="user_option">
                            <a href="registration.php" class="user_link">
                                <i class="fa fa-user" aria-hidden="true"></i>
                            </a>

                            <?php
                                if (isset($_SESSION['auth_user']['user_id'])) {
                                    $cart_count = mysqli_query($con, "SELECT * FROM `cart` WHERE user_id='{$_SESSION['auth_user']['user_id']}'");
                                    $cart_rows = mysqli_num_rows($cart_count);
                                } elseif (isset($_SESSION['auth_user']['fb_user_id'])) {
                                    $cart_count = mysqli_query($con, "SELECT * FROM `cart` WHERE fb_user_id='{$_SESSION['auth_user']['fb_user_id']}'");
                                    $cart_rows = mysqli_num_rows($cart_count);
                                } elseif (isset($_SESSION['google_id'])) {
                                    $cart_count = mysqli_query($con, "SELECT * FROM `cart` WHERE google_user_id='{$_SESSION['google_id']}'");
                                    $cart_rows = mysqli_num_rows($cart_count);
                                } else {
                                    $cart_rows = '';
                                }
                                ?>
                                <?php
                                if (isset($_SESSION['auth_user']['user_id'])) {

                                ?>
                                    <a href="view_cart.php" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span class="bg-danger" style="padding: 5px; border-radius: 50%;font-size: 9px; position: absolute; top: 10px;"><?php echo $cart_rows  ?></span></i>
                                    </a>

                                <?php
                                } elseif (isset($_SESSION['auth_user']['fb_user_id'])) {
                                ?>
                                    <a href="view_cart.php" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span class="bg-danger" style="padding: 5px; border-radius: 50%;font-size: 9px; position: absolute; top: 10px;"><?php echo $cart_rows  ?></span></i>
                                    </a>
                                <?php
                                } elseif ( isset($_SESSION['google_id'])) {
                                ?>
                                    <a href="view_cart.php" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span class="bg-danger" style="padding: 5px; border-radius: 50%;font-size: 9px; position: absolute; top: 10px;"><?php echo $cart_rows  ?></span></i>
                                    </a>

                                <?php
                                } else {
                                ?>
                                    <a href="*" class="user_link">
                                        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:20px;"><span></span></i>
                                    </a>
                                <?php
                                }
                                ?>

                        </div>
                    </div>
                </nav>
            </div>
        </header>
        <!-- end header section -->
    </div>

<?php
if (isset($_REQUEST['id'])) {

    $id = $_REQUEST['id'];

    $pro_details = mysqli_query($con, "SELECT * FROM `product` WHERE `id` = '$id' ");
    //$pro_details = mysqli_query($con, "SELECT p.*, c.name AS cname FROM product p, categories c WHERE  c.id = p.category_id");
    $pd_row = mysqli_fetch_array($pro_details);

?> 

<body class="sub_page">
<form action="insert_cart.php" method="Post" enctype="multipart/form-data">
        <input type="hidden" name="id"  value="<?php echo $pd_row["id"]; ?>" />
        <input type="hidden" name="name" value="<?php echo $pd_row["name"]; ?>" />
        <input type="hidden" name="description" value="<?php echo $pd_row["description"]; ?>" />
        <input type="hidden" name="price" value="<?php echo $pd_row["price"]; ?>" />
        <input type="hidden" name="image" value="<?php echo $pd_row["image"]; ?>" />     
    <div class="py-3 py-md-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-5 mt-3">
                    <div class="img-box">
                        <div class="col-12" style="margin-top: 3rem;">
                            <img src="Admin/images/product/<?php echo $pd_row['image']; ?>" width="400" height="300" alt="">
                        </div>


                    </div>
                </div>
                <div class="col-md-7 mt-3">
                    <div class="product-view">
                        <h3 style="font-weight: bold;" class="my-3"><?php echo $pd_row['name']; ?></h3>
                        <p style="*"> <?= $pd_row['description']; ?></p>
                        <!-- <h5 style="font-weight: bold;" class="my-3">Category: <?= $pd_row['cname']; ?></h5> -->
                        <hr><br><br>


                        <div class="row">
                            <div class="col-md-3">
                                <select class="form-select" style="width: 10rem; height:2rem;" name="taste" aria-label="Default select example">
                                    <option selected>select taste</option>
                                    <option value="spicy">SPICY</option>
                                    <option value="crunchy">CRUNCHY</option>
                                    <option value="normal">NORMALL</option>
                                </select>
                            </div>


                            <div class="col-md-3">
                                <select class="form-select" style="width: 10rem; height:2rem;" name="size" aria-label="Default select example">
                                    <option selected>select size</option>
                                    <option value="small">SMALL</option>
                                    <option value="medium">MEDIUM</option>
                                    <option value="large">LARGE</option>
                                </select>

                            </div>



                            <div class="col-md-6">
                                <div class="input-group nice">
                                    <!-- <span class="btn btn1"><i class="fa fa-minus"></i></span> -->
                                    <input type="number" value="1" name="quantity"  style="width: 10rem; height:2.5rem; text-align: center; border-radius: 5px; border: solid 1px #e8e8e8;" placeholder="add quantity" class="input-quantity" />
                                    <!-- <span class="btn btn1"><i class="fa fa-plus"></i></span> -->
                                </div>
                            </div>



                        </div>



                        </div>


                        <div class=" py-2 px-3 mt-4">
                            <h2 class="my-3">Price: <?= $pd_row['price'] .' $'; ?></h2>
                        </div>

                        
                        <?php
                        
                        $user= $_SESSION['auth_user']['user_id'] ?? $_SESSION['auth_user']['fb_user_id'] ?? $_SESSION['google_id'] ?? '';
                        ?>
                        <div class="mt-4">
                            <button   class="btn btn-primary btn-lg btn-flat" name="add_to_cart" value="<?php echo $user;?>"><div>
                                <i class="fa fa-shopping-cart fa-lg mr-2"></i>
                                Add to Cart
                            </div></button> 

                            <!-- <div class="btn btn-secondary btn-lg btn-flat">
                                <i class="fa fa-heart fa-lg mr-2"></i>
                                Add to Wishlist
                            </div> -->
                        </div>

                        </form>

                    </div>
                </div>
            </div>

        </div>
    </div>
<?php
}
?>
</body>
<?php

include("includes/footer.php");
include("includes/scripts.php");
?>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js">
    