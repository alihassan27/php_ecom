<?php
session_start();
include('config/connection.php');

    $id = $_REQUEST["id"];
    $query = "DELETE FROM `cart` WHERE `id` = '$id'";
    $res = mysqli_query($con, $query);
    if($res){
        echo "DELETED";
        header("Location: view_cart.php");
    }
    else{
        // $_SESSION ['message'] = "Not Deleted Sucessfully!";
        header("location: view_cart.php");
        exit(0);
    }

?>
