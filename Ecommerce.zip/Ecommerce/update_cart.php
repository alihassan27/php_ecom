<?php
session_start();
include"config/connection.php";
require_once('paypal/dbclass.php');

$id = $_POST['id'];
$quantity = $_POST['quantity'];
$price = $_POST['price'];
$total = $_POST['total'];

$up_query = mysqli_query($con, "UPDATE `cart` SET quantity='$quantity',price='$price',total='$total'  WHERE id='$id'");
?> <table class="table table-bordered">
<thead>
    <tr>
        <th>Name</th>
        <th>Image</th>
        <th>Description</th>
        <th>Taste</th>
        <th>Size</th>
        <th>Real Price</th>
        <th>Quantity</th>
        <th>New Total</th>
        <th>Action</th>
    </tr>
</thead>
<tbody>

    <?php
    if (isset($_SESSION['auth_user']['user_id'])) {
    ?>
    <?php
    $user_id = $_SESSION['auth_user']['user_id'];
    $uc_query = mysqli_query($con, "SELECT * FROM `cart` Where `user_id`='{$_SESSION['auth_user']['user_id']}'");
    $total = 0;
    while ($uc_row = mysqli_fetch_array($uc_query)) {
    ?>
    <tr>
        <td><?php echo $uc_row['name']; ?></td>
        <td><img src="Admin/images/product/<?= $uc_row['image']; ?>" alt="" height="80" width="80" ;></td>
        <td><?php echo $uc_row['description'] ?></td>
        <td><?php echo $uc_row['taste'] ?></td>
        <td><?php echo $uc_row['size'] ?></td>
        <td class="real-price"><?php echo $uc_row['price'] .' $'; ?></td>    
    <td>
    <form id="frm<?php echo $uc_row['id']; ?>">
                    <input type="hidden" name="id" value="<?php echo $uc_row['id'] ?>">
                    <input type="hidden" class="price" name="price" value="<?php echo $uc_row['price'] ?>">
                    <input type="number" name="quantity" value="<?php echo $uc_row['quantity'] ?>" onchange="up_qty(<?php echo $uc_row['id']; ?>)" onkeyup="up_qty(<?php echo $uc_row['id']; ?>)">
                </form>
    </td>
                <td>
                <?php echo $uc_row['total']; ?>
            </td>
    <td>
        <a href="del_cart.php?id= <?= $uc_row['id']; ?>"  onclick="return confirm('Are You Sure, You want to Delete?')" name="btn_del" class="btn btn-danger"><i class="fa fa-trash"></a></td></i>
    </tr>
    <?php
                $total = $total + ($uc_row["quantity"] * $uc_row["price"]);
        }
    ?>
            <tr>
            <td class="total-text" align="right" colspan="7">Total amount ($)</td>
            <td> <?php echo number_format($total, 2); ?></td>
        </tr>

    <?php
    } elseif (isset($_SESSION['auth_user']['fb_user_id'])) {
    ?>
    <?php
    $user_id = $_SESSION['auth_user']['fb_user_id'];
    $uc_query = mysqli_query($con, "SELECT * FROM `cart` Where `fb_user_id`='{$_SESSION['auth_user']['fb_user_id']}'");
    $total = 0;
    while ($uc_row = mysqli_fetch_array($uc_query)) {
    ?>
    <tr>
        <td><?php echo $uc_row['name']; ?></td>
        <td><img src="Admin/images/product/<?= $uc_row['image']; ?>" alt="" height="80" width="80" ;></td>
        <td><?php echo $uc_row['description'] ?></td>
        <td><?php echo $uc_row['taste'] ?></td>
        <td><?php echo $uc_row['size'] ?></td>
        <td class="real-price"><?php echo $uc_row['price'] .' $'; ?></td>    
    <td>
    <form id="frm<?php echo $uc_row['id']; ?>">
                    <input type="hidden" name="id" value="<?php echo $uc_row['id'] ?>">
                    <input type="hidden" class="price" name="price" value="<?php echo $uc_row['price'] ?>">
                    <input type="number" name="quantity" value="<?php echo $uc_row['quantity'] ?>" onchange="up_qty(<?php echo $uc_row['id']; ?>)" onkeyup="up_qty(<?php echo $uc_row['id']; ?>)">
                </form>
    </td>
                <td>
                <?php echo $uc_row['total']; ?>
            </td>
    <td>
        <a href="del_cart.php?id= <?= $uc_row['id']; ?>"  onclick="return confirm('Are You Sure, You want to Delete?')" name="btn_del" class="btn btn-danger"><i class="fa fa-trash"></a></td></i>
    </tr>
    <?php
                $total = $total + ($uc_row["quantity"] * $uc_row["price"]);
        }
    ?>
            <tr>
            <td class="total-text" align="right" colspan="7">Total amount ($)</td>
            <td> <?php echo number_format($total, 2); ?></td>
        </tr>

                                    <!-- google user update cart -->

   <?php
   } elseif (isset($_SESSION['google_id'])) {
?>     
    <?php
    $user_id = $_SESSION['google_id'];
    $uc_query = mysqli_query($con, "SELECT * FROM `cart` Where `google_user_id`='{$_SESSION['google_id']}'");
    $total = 0;
    while ($uc_row = mysqli_fetch_array($uc_query)) {
    ?>
    <tr>
        <td><?php echo $uc_row['name']; ?></td>
        <td><img src="Admin/images/product/<?= $uc_row['image']; ?>" alt="" height="80" width="80" ;></td>
        <td><?php echo $uc_row['description'] ?></td>
        <td><?php echo $uc_row['taste'] ?></td>
        <td><?php echo $uc_row['size'] ?></td>
        <td class="real-price"><?php echo $uc_row['price'] .' $'; ?></td>    
    <td>
    <form id="frm<?php echo $uc_row['id']; ?>">
                    <input type="hidden" name="id" value="<?php echo $uc_row['id'] ?>">
                    <input type="hidden" class="price" name="price" value="<?php echo $uc_row['price'] ?>">
                    <input type="number" name="quantity" value="<?php echo $uc_row['quantity'] ?>" onchange="up_qty(<?php echo $uc_row['id']; ?>)" onkeyup="up_qty(<?php echo $uc_row['id']; ?>)">
                </form>
    </td>
                <td>
                <?php echo $uc_row['total']; ?>
            </td>
    <td>
        <a href="del_cart.php?id= <?= $uc_row['id']; ?>"  onclick="return confirm('Are You Sure, You want to Delete?')" name="btn_del" class="btn btn-danger"><i class="fa fa-trash"></a></td></i>
    </tr>
    <?php
                $total = $total + ($uc_row["quantity"] * $uc_row["price"]);
        }
    ?>
            <tr>
            <td class="total-text" align="right" colspan="7">Total amount ($)</td>
            <td> <?php echo number_format($total, 2); ?></td>
        </tr>
        <?php 
        }
        ?>
        
</tbody>
</table>
</div>
</div>




    </section>        

