<?php

session_start();
include('config/connection.php');

if (isset($_POST['register_btn'])) {

    $uername = mysqli_escape_string($con, $_POST['uername']);
    $email = mysqli_escape_string($con, $_POST['email']);
    $password = mysqli_escape_string($con, $_POST['password']);
    $confirm_password = mysqli_escape_string($con, $_POST['cpassword']);

    if ($password == $confirm_password) {

        // check email

        $checkemail = "SELECT email FROM user WHERE email='$email'";

        $checkemail_run = mysqli_query($con, $checkemail);

        if (mysqli_num_rows($checkemail_run) > 0) {

            // already emial exist
            $_SESSION['message'] = "Email already exist";

            header("Location: registration.php");
            exit(0);
        } else {
            $user_query = "INSERT INTO `user` (`username`,`email`,`password`) VALUES ('$username','$email','$password')";
            $user_query_run = mysqli_query($con, $user_query);

            if ($user_query_run) {

                $_SESSION['message'] = "Register successfully";

                header("Location: login.php");
                exit(0);
            } else {
                $_SESSION['message'] = "Something went wrong";

                header("Location: registration.php");
                exit(0);
            }
        }
    } else {
        $_SESSION['message'] = "Password and confirm password does not match";

        header("Location: registration.php");
        exit(0);
    }
} else {
    header("Location: registration.php");
    exit(0);
}


