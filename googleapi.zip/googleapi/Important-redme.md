DO THESE THINGS FIRST

#Download Google API Client Library for PHP

Do run the below command on root directory

#composer require google/apiclient:"^2.0"

#on Config.php file
====================

#Set the OAuth 2.0 Client ID

#Set the OAuth 2.0 Client Secret key

#Set the OAuth 2.0 Redirect URI

================================